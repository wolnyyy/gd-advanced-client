# VoxHack

A professional, modular advanced client for Geometry Dash with 150+ features.

## Features

This mod provides comprehensive tools for:

- **Practice Mode**: Enhanced checkpoint system and training tools
- **Replay System**: Record and playback runs
- **Editor Tools**: Advanced editing utilities and color management
- **Gameplay Enhancements**: FPS counter, speedhack, noclip, and more
- **UI Customization**: Themeable interface with multiple color schemes
- **Performance**: FPS unlock and optimization features

## Usage

Click the "VOXHACK" button in the main menu to open the client panel.

## Support

For issues or feature requests, please contact the developer team.
