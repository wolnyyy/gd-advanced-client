# GD Advanced Client – Feature Specification

## GAMEPLAY / UŁATWIENIA (1–40)
| # | Name | Description | Hook |
|---|------|-------------|------|
| 1 | God Mode | Prevents death. destroyPlayer hook returns early | PlayLayerHook |
| 2 | Auto Complete | Calls levelComplete() on init | PlayLayerHook |
| 3 | Instant Win | Wins on first frame | PlayLayerHook |
| 4 | Practice Music Sync | Keeps music position in sync | PlayLayerHook |
| 5 | Start Position Bypass | Removes start pos restrictions | PlayLayerHook |
| 6 | No Clip | Skips destroyPlayer entirely | PlayLayerHook |
| 7 | Safe Mode | Disables progress saving | PlayLayerHook |
| 8 | Speed Hack | Multiplies scheduler time scale | PlayLayerHook |
| 9 | Slow Motion | Sets time scale to 0.25x | PlayLayerHook |
| 10 | Frame Advance | Skips update unless triggered | PlayLayerHook |
| 11 | Hitbox Viewer | Renders all physics hitboxes | PlayLayerHook |
| 12 | Show Player Hitbox Only | Only player hitbox shown | PlayLayerHook |
| 13 | Show Object Hitboxes | All object hitboxes shown | PlayLayerHook |
| 14 | Disable Spikes | Spike objects ignored in collision | PlayLayerHook |
| 15 | Disable Sawblades | Sawblade objects ignored | PlayLayerHook |
| 16 | Disable Moving Objects | Stops platform/hazard movement | PlayLayerHook |
| 17 | No Death Effect | Skips death explosion animation | PlayLayerHook |
| 18 | No Screen Shake | Clears cameraShake state | VisualToggles |
| 19 | No Flash | Disables flash trigger effects | PlayLayerHook |
| 20 | No Pulse | Disables pulse trigger effects | PlayLayerHook |
| 21 | No Background | Hides background sprite | VisualToggles |
| 22 | No Decorations | Hides decoration layer | VisualToggles |
| 23 | No Particles | Disables CCParticleSystem | PlayLayerHook |
| 24 | No Glow | Hides glow sprites | PlayLayerHook |
| 25 | No Mirror Portal | Ignores mirror portal triggers | PlayLayerHook |
| 26 | No Dual Mode | Ignores dual mode triggers | PlayLayerHook |
| 27 | Force Single Mode | Forces player count to 1 | PlayLayerHook |
| 28 | Disable Gravity Portals | Ignores gravity flips | PlayLayerHook |
| 29 | Jump Hack | Allows mid-air jumping | PlayLayerHook |
| 30 | Infinite Jumps | Resets isOnGround every frame | PlayLayerHook |
| 31 | Auto Jump | Auto-calls pushButton(0) | PlayLayerHook |
| 32 | Auto Click | Same as auto jump | PlayLayerHook |
| 33 | Click Bot | Plays stored click sequence | ReplayManager |
| 34 | Bot Recording | Records pushButton calls | ReplayManager |
| 35 | Bot Playback | Replays recorded frames | ReplayManager |
| 36 | Random Input Bot | Random pushButton intervals | PlayLayerHook |
| 37 | Show CPS | Counts clicks/sec, CCLabel | PlayLayerHook |
| 38 | Accuracy Tracker | % of frames alive | SessionManager |
| 39 | Death Counter | Counts deaths | SessionManager |
| 40 | Attempt Counter Editor | Locally edits attempt counter | ConfigManager |

## PRACTICE / TRENING (41–65)
All offline only, stored locally in SessionManager/CheckpointManager.

## EDYTOR POZIOMÓW (66–105)
All editor features require being in LevelEditorLayer.
UnlockAllObjects bypasses the locked-objects check.
RemoveObjectLimit patches the 80,000 object cap.

## WIZUALNE / UI (106–125)
Purely cosmetic. No effect on game progress.

## KONTO / SYSTEM (126–150)
All local-only. SafeMode/SafeRunMode prevent progress upload.
Online leaderboards and achievements are never modified.
