#include "TrainingTools.hpp"
#include "../core/FeatureManager.hpp"
#include "../../include/Config.hpp"
#include "../utils/Logger.hpp"

namespace TrainingTools {

void drawHitboxTrail(PlayerObject* player, cocos2d::CCNode* layer) {
    if (!player || !layer) return;
    if (!FeatureManager::get().isEnabled(FeatureID::HitboxTrail)) return;

    // Draw a small dot at current player position
    auto dot = cocos2d::CCLayerColor::create({255, 200, 0, 120}, 4.f, 4.f);
    dot->setPosition(player->getPosition());
    layer->addChild(dot, 5);

    // Fade out after 1 second
    dot->runAction(cocos2d::CCSequence::create(
        cocos2d::CCDelayTime::create(1.0f),
        cocos2d::CCFadeOut::create(0.3f),
        cocos2d::CCRemoveSelf::create(),
        nullptr
    ));
}

void renderTimingWindow(cocos2d::CCNode* layer, float percent) {
    if (!FeatureManager::get().isEnabled(FeatureID::TimingWindowDisplay)) return;
    // Timing window visualization placeholder
    Logger::info("Timing window at " + std::to_string(percent) + "%");
}

void renderWaveTrail(PlayerObject* player, cocos2d::CCNode* layer) {
    if (!player || !layer) return;
    if (!FeatureManager::get().isEnabled(FeatureID::WaveTrailVisualizer)) return;

    auto trail = cocos2d::CCLayerColor::create({0, 200, 255, 80}, 3.f, 3.f);
    trail->setPosition(player->getPosition());
    layer->addChild(trail, 4);
    trail->runAction(cocos2d::CCSequence::create(
        cocos2d::CCDelayTime::create(0.5f),
        cocos2d::CCFadeOut::create(0.2f),
        cocos2d::CCRemoveSelf::create(),
        nullptr
    ));
}

} // namespace TrainingTools
