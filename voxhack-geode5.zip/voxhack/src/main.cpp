// main.cpp - GD Advanced Client
// The actual Geode mod entry is in src/core/ModEntry.cpp via $on_mod(Loaded)
// This file exists as the primary compilation unit.
#include <Geode/Geode.hpp>
