#pragma once
#include <Geode/Geode.hpp>
#include <functional>

class ToggleSwitch : public cocos2d::CCNode {
public:
    static ToggleSwitch* create(bool initialState, std::function<void(bool)> onChange);
    bool init(bool initialState, std::function<void(bool)> onChange);

    void setState(bool state, bool animate = true);
    bool getState() const { return m_state; }

    bool onTouchBegan(cocos2d::CCTouch*, cocos2d::CCEvent*);
    void onTouchEnded(cocos2d::CCTouch*, cocos2d::CCEvent*);

private:
    void updateVisuals(bool animate);

    cocos2d::CCLayerColor* m_track  {nullptr};
    cocos2d::CCLayerColor* m_thumb  {nullptr};
    std::function<void(bool)> m_onChange;
    bool m_state {false};

    static constexpr float W = 44.f;
    static constexpr float H = 24.f;
    static constexpr float THUMB_R = 10.f;
};
