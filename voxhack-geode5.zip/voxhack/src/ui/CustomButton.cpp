#include "CustomButton.hpp"

using namespace cocos2d;

CustomButton* CustomButton::create(
    const std::string& label, const ccColor4B& bgColor,
    const ccColor4B& textColor, const CCSize& size,
    std::function<void()> callback)
{
    auto node = new CustomButton();
    if (node && node->init(label, bgColor, textColor, size, callback)) {
        node->autorelease();
        return node;
    }
    CC_SAFE_DELETE(node);
    return nullptr;
}

bool CustomButton::init(
    const std::string& label, const ccColor4B& bgColor,
    const ccColor4B& textColor, const CCSize& size,
    std::function<void()> callback)
{
    if (!CCNode::init()) return false;

    m_callback = callback;
    m_bgColor  = bgColor;
    setContentSize(size);

    m_bg = CCLayerColor::create(bgColor, size.width, size.height);
    m_bg->setPosition({0,0});
    addChild(m_bg);

    m_label = CCLabelTTF::create(label.c_str(), "Arial", 14.f);
    m_label->setColor({textColor.r, textColor.g, textColor.b});
    m_label->setPosition({size.width * 0.5f, size.height * 0.5f});
    addChild(m_label);

    setTouchEnabled(true);
    return true;
}

void CustomButton::setLabel(const std::string& label) {
    if (m_label) m_label->setString(label.c_str());
}

void CustomButton::setEnabled(bool enabled) {
    m_enabled = enabled;
    setOpacity(enabled ? 255 : 120);
}

bool CustomButton::onTouchBegan(CCTouch* touch, CCEvent*) {
    if (!m_enabled) return false;
    auto pos = convertToNodeSpace(touch->getLocation());
    auto size = getContentSize();
    if (pos.x >= 0 && pos.x <= size.width && pos.y >= 0 && pos.y <= size.height) {
        m_pressed = true;
        m_bg->setOpacity(180);
        return true;
    }
    return false;
}

void CustomButton::onTouchEnded(CCTouch* touch, CCEvent*) {
    if (!m_pressed) return;
    m_pressed = false;
    m_bg->setOpacity(255);
    auto pos = convertToNodeSpace(touch->getLocation());
    auto size = getContentSize();
    if (pos.x >= 0 && pos.x <= size.width && pos.y >= 0 && pos.y <= size.height) {
        if (m_callback) m_callback();
    }
}
