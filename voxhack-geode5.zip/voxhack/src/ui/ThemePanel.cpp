#include "ThemePanel.hpp"
#include "../core/ThemeManager.hpp"
#include "CustomButton.hpp"

using namespace cocos2d;

ThemePanel* ThemePanel::create(float w, float h) {
    auto n = new ThemePanel();
    if (n && n->init(w, h)) { n->autorelease(); return n; }
    CC_SAFE_DELETE(n); return nullptr;
}

bool ThemePanel::init(float w, float h) {
    if (!CCNode::init()) return false;
    setContentSize({w, h});
    rebuildButtons(w, h);
    return true;
}

void ThemePanel::rebuildButtons(float w, float h) {
    removeAllChildren();
    auto& col = ThemeManager::get().colors();

    auto title = CCLabelTTF::create("Theme", "Arial", 14.f);
    title->setColor({col.text.r, col.text.g, col.text.b});
    title->setPosition({w * 0.5f, h - 20.f});
    addChild(title);

    struct ThemeEntry { std::string name; ThemeType type; ccColor4B preview; };
    std::vector<ThemeEntry> themes = {
        {"Default", ThemeType::Default, {180,180,180,255}},
        {"Green",   ThemeType::Green,   {80,200,80,255}},
        {"Pink",    ThemeType::Pink,    {255,105,180,255}},
        {"Blue",    ThemeType::Blue,    {80,150,255,255}},
        {"Purple",  ThemeType::Purple,  {160,80,255,255}}
    };

    float btnW = 80.f, btnH = 28.f;
    float startX = (w - (btnW + 8.f) * themes.size()) * 0.5f + btnW * 0.5f;
    float y = h * 0.5f;

    for (int i = 0; i < (int)themes.size(); ++i) {
        auto& e = themes[i];
        float x = startX + i * (btnW + 8.f);

        auto bg = CCLayerColor::create(e.preview, btnW, btnH);
        bg->setPosition({x - btnW * 0.5f, y - btnH * 0.5f});
        addChild(bg);

        auto lbl = CCLabelTTF::create(e.name.c_str(), "Arial", 11.f);
        lbl->setColor({255,255,255});
        lbl->setPosition({x, y});
        addChild(lbl);

        ThemeType captType = e.type;
        ThemePanel* self = this;
        float cw = w, ch = h;

        // CCMenuItem approach
        auto item = CCMenuItemLabel::create(lbl, [captType, self, cw, ch](CCObject*) {
            ThemeManager::get().applyTheme(captType);
            self->removeAllChildren();
            self->rebuildButtons(cw, ch);
        });
        auto menu = CCMenu::create(item, nullptr);
        menu->setPosition({x - btnW*0.5f, y - btnH*0.5f});
        menu->setContentSize({btnW, btnH});
        addChild(menu);
    }

    auto current = ThemeManager::get().getCurrentName();
    auto info = CCLabelTTF::create(("Active: " + current).c_str(), "Arial", 11.f);
    info->setColor({col.textSecondary.r, col.textSecondary.g, col.textSecondary.b});
    info->setPosition({w * 0.5f, 20.f});
    addChild(info);

    return;
}
