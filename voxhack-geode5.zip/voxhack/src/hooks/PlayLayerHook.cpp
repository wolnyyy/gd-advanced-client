#include <Geode/Geode.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include "../core/FeatureManager.hpp"
#include "../core/ConfigManager.hpp"
#include "../core/SessionManager.hpp"
#include "../replay/ReplayManager.hpp"
#include "../../include/Config.hpp"
#include "../../include/Globals.hpp"

using namespace geode::prelude;
using namespace cocos2d;

// FPS overlay label (forward declared)
static CCLabelTTF* s_fpsLabel   = nullptr;
static CCLabelTTF* s_cpsLabel   = nullptr;
static CCLabelTTF* s_pctLabel   = nullptr;
static int         s_frameCount = 0;
static float       s_fpsTimer   = 0.f;
static float       s_fps        = 0.f;
static int         s_cps        = 0;
static float       s_cpsTimer   = 0.f;
static int         s_clicksBuf  = 0;

class $modify(GDACPlayLayer, PlayLayer) {
public:
    // ── Init ──────────────────────────────────────────────────────────────────
    bool init(GJGameLevel* level, bool p1, bool p2) {
        if (!PlayLayer::init(level, p1, p2)) return false;

        SessionManager::get().reset();
        SessionManager::get().onAttemptStart();

        auto& fm = FeatureManager::get();

        // Speed hack
        if (fm.isEnabled(FeatureID::SpeedHack)) {
            float spd = (float)ConfigManager::get().getDouble(ConfigKeys::SPEED_HACK, 1.0);
            CCDirector::sharedDirector()->getScheduler()->setTimeScale(spd);
        }
        // Slow motion
        else if (fm.isEnabled(FeatureID::SlowMotion)) {
            CCDirector::sharedDirector()->getScheduler()->setTimeScale(0.25f);
        }

        // FPS counter overlay
        if (fm.isEnabled(FeatureID::ShowFPS)) {
            s_fpsLabel = CCLabelTTF::create("FPS: 0", "Arial", 12.f);
            s_fpsLabel->setColor({255,255,100});
            s_fpsLabel->setAnchorPoint({0.f, 1.f});
            auto win = CCDirector::sharedDirector()->getWinSize();
            s_fpsLabel->setPosition({5.f, win.height - 5.f});
            addChild(s_fpsLabel, GDACConst::Z_ORDER_OVERLAY);
        }

        // CPS counter overlay
        if (fm.isEnabled(FeatureID::ShowCPS)) {
            s_cpsLabel = CCLabelTTF::create("CPS: 0", "Arial", 12.f);
            s_cpsLabel->setColor({100,255,200});
            s_cpsLabel->setAnchorPoint({0.f, 1.f});
            auto win = CCDirector::sharedDirector()->getWinSize();
            s_cpsLabel->setPosition({5.f, win.height - 22.f});
            addChild(s_cpsLabel, GDACConst::Z_ORDER_OVERLAY);
        }

        // Exact percent
        if (fm.isEnabled(FeatureID::ShowExactPercent)) {
            s_pctLabel = CCLabelTTF::create("0.00%", "Arial", 11.f);
            s_pctLabel->setColor({200,200,255});
            s_pctLabel->setAnchorPoint({1.f, 1.f});
            auto win = CCDirector::sharedDirector()->getWinSize();
            s_pctLabel->setPosition({win.width - 5.f, win.height - 5.f});
            addChild(s_pctLabel, GDACConst::Z_ORDER_OVERLAY);
        }

        // Frame counter
        s_frameCount = 0;
        s_fpsTimer   = 0.f;
        s_fps        = 0.f;

        // Bot recording
        if (fm.isEnabled(FeatureID::BotRecording)) {
            ReplayManager::get().startRecording();
        }

        // Bot playback
        if (fm.isEnabled(FeatureID::BotPlayback)) {
            ReplayManager::get().startPlayback();
        }

        // FPS unlock
        if (fm.isEnabled(FeatureID::FPSUnlocker)) {
            int cap = ConfigManager::get().getInt(ConfigKeys::FPS_CAP, 240);
            CCDirector::sharedDirector()->setAnimationInterval(1.0 / cap);
        }

        // Minimal HUD
        if (fm.isEnabled(FeatureID::MinimalHUD)) {
            if (m_percentLabel) m_percentLabel->setVisible(false);
        }

        return true;
    }

    // ── Update ────────────────────────────────────────────────────────────────
    void update(float dt) {
        auto& fm = FeatureManager::get();

        // Frame advance
        if (fm.isEnabled(FeatureID::FrameAdvance)) {
            // Skip update unless space pressed (handled via key hook)
            return;
        }

        PlayLayer::update(dt);
        ++s_frameCount;

        // FPS counter
        if (fm.isEnabled(FeatureID::ShowFPS) && s_fpsLabel) {
            s_fpsTimer += dt;
            if (s_fpsTimer >= 0.5f) {
                s_fps      = s_frameCount / s_fpsTimer;
                s_fpsTimer = 0.f;
                s_frameCount = 0;
                char buf[32];
                snprintf(buf, sizeof(buf), "FPS: %.1f", s_fps);
                s_fpsLabel->setString(buf);
            }
        }

        // CPS counter
        if (fm.isEnabled(FeatureID::ShowCPS) && s_cpsLabel) {
            s_cpsTimer += dt;
            if (s_cpsTimer >= 1.f) {
                s_cps = s_clicksBuf;
                s_clicksBuf = 0;
                s_cpsTimer  = 0.f;
                char buf[32];
                snprintf(buf, sizeof(buf), "CPS: %d", s_cps);
                s_cpsLabel->setString(buf);
            }
        }

        // Exact percent
        if (fm.isEnabled(FeatureID::ShowExactPercent) && s_pctLabel) {
            float pct = m_gameState ? m_percentageLabel : 0.f;
            // Use actual level progress calculation
            if (m_player1 && m_levelLength > 0.f) {
                pct = (m_player1->getPositionX() / m_levelLength) * 100.f;
                if (pct > 100.f) pct = 100.f;
                SessionManager::get().onProgressUpdate(pct);
            }
            char buf[16];
            snprintf(buf, sizeof(buf), "%.3f%%", pct);
            s_pctLabel->setString(buf);
        }

        // Auto jump
        if (fm.isEnabled(FeatureID::AutoJump)) {
            pushButton(0, false);
        }

        // Bot playback
        if (fm.isEnabled(FeatureID::BotPlayback) && ReplayManager::get().isPlaying()) {
            auto frame = ReplayManager::get().getNextFrame();
            if (frame.holding) pushButton(0, false);
            else releaseButton(0, false);
        }

        // Auto restart
        if (fm.isEnabled(FeatureID::AutoRestart)) {
            if (m_isDead) {
                resetLevel();
            }
        }
    }

    // ── Death ─────────────────────────────────────────────────────────────────
    void destroyPlayer(PlayerObject* p, GameObject* obj) {
        auto& fm = FeatureManager::get();

        if (fm.isEnabled(FeatureID::GodMode))  return;
        if (fm.isEnabled(FeatureID::NoClip))   return;

        float pct = (m_player1 && m_levelLength > 0.f)
            ? (m_player1->getPositionX() / m_levelLength) * 100.f
            : 0.f;

        SessionManager::get().onDeath(pct);

        if (fm.isEnabled(FeatureID::NoDeathEffect)) {
            // Don't call base → skip explosion
            // But we need to still mark player dead
            PlayLayer::destroyPlayer(p, obj);
            return;
        }

        if (!fm.isEnabled(FeatureID::DisableDeathSound)) {
            PlayLayer::destroyPlayer(p, obj);
        } else {
            PlayLayer::destroyPlayer(p, obj);
        }
    }

    // ── Push button (jump/click) ──────────────────────────────────────────────
    void pushButton(int p, bool p2) {
        auto& fm = FeatureManager::get();

        ++s_clicksBuf;
        SessionManager::get().onClick();
        SessionManager::get().onJump();

        // Record for bot
        if (fm.isEnabled(FeatureID::BotRecording)) {
            float x = m_player1 ? m_player1->getPositionX() : 0.f;
            float y = m_player1 ? m_player1->getPositionY() : 0.f;
            ReplayManager::get().recordFrame(s_frameCount, true, x, y);
        }

        PlayLayer::pushButton(p, p2);

        // Infinite jumps: re-allow jump immediately
        if (fm.isEnabled(FeatureID::InfiniteJumps) && m_player1) {
            m_player1->m_isOnGround = true;
        }
    }

    // ── Level complete ────────────────────────────────────────────────────────
    void levelComplete() {
        SessionManager::get().onLevelComplete();
        SessionManager::get().save();

        if (ReplayManager::get().isRecording())
            ReplayManager::get().stopRecording();

        // Safe run mode: don't save progress
        if (FeatureManager::get().isEnabled(FeatureID::SafeRunMode)) {
            // Don't call base to prevent saving
            return;
        }

        PlayLayer::levelComplete();
    }

    // ── Reset level ───────────────────────────────────────────────────────────
    void resetLevel() {
        SessionManager::get().onAttemptStart();
        s_frameCount = 0;
        PlayLayer::resetLevel();
    }
};
