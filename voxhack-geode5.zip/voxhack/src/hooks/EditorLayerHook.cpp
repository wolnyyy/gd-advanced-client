#include <Geode/Geode.hpp>
#include <Geode/modify/EditorUI.hpp>
#include <Geode/modify/LevelEditorLayer.hpp>
#include "../core/FeatureManager.hpp"
#include "../core/ConfigManager.hpp"
#include "../../include/Config.hpp"
#include "../../include/Globals.hpp"

using namespace geode::prelude;
using namespace cocos2d;

// ── EditorUI hook ─────────────────────────────────────────────────────────────
class $modify(GDACEditorUI, EditorUI) {
public:
    bool init(LevelEditorLayer* lel) {
        if (!EditorUI::init(lel)) return false;

        auto& fm = FeatureManager::get();

        // Dark Mode Editor
        if (fm.isEnabled(FeatureID::DarkModeEditor)) {
            if (auto bg = lel->m_background) {
                bg->setColor({20, 20, 20});
            }
        }

        // Unlock All Objects (bypass object ID limits)
        // This is handled via LevelEditorLayer hook below

        return true;
    }
};

// ── LevelEditorLayer hook ─────────────────────────────────────────────────────
class $modify(GDACEditorLayer, LevelEditorLayer) {
public:
    bool init(GJGameLevel* level, bool p) {
        if (!LevelEditorLayer::init(level, p)) return false;
        auto& fm = FeatureManager::get();

        // Remove object limit
        if (fm.isEnabled(FeatureID::RemoveObjectLimit)) {
            // Handled via object limit patch below
        }

        // Trigger visualizer: color-code trigger objects
        if (fm.isEnabled(FeatureID::TriggerVisualizer)) {
            // Objects are added dynamically; hook createObject instead
        }

        return true;
    }

    // Object limit bypass
    bool addToSection(GameObject* obj) {
        auto& fm = FeatureManager::get();
        // Normally limited to ~80000 objects; we skip the count check
        if (fm.isEnabled(FeatureID::RemoveObjectLimit) ||
            fm.isEnabled(FeatureID::ObjectCounterBypass))
        {
            // Direct base call, bypassing limit checks that happen before
            return LevelEditorLayer::addToSection(obj);
        }
        return LevelEditorLayer::addToSection(obj);
    }

    // Free camera in editor
    void scrollWheel(float y, float x) {
        auto& fm = FeatureManager::get();
        if (fm.isEnabled(FeatureID::FreeCamera)) {
            // Allow unrestricted scroll
        }
        LevelEditorLayer::scrollWheel(y, x);
    }
};
