#pragma once
#include <Geode/Geode.hpp>
namespace EditorEnhancements {
    void applySnapToGrid(LevelEditorLayer* layer, bool enable);
    void showHiddenObjects(LevelEditorLayer* layer);
    void enableFreeCamera(EditorUI* ui);
    void applyDarkMode(LevelEditorLayer* layer);
    void massSelectAll(EditorUI* ui);
}
