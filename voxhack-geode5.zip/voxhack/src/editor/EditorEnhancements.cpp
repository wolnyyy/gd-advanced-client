#include "EditorEnhancements.hpp"
#include "../core/FeatureManager.hpp"
#include "../../include/Config.hpp"
#include "../utils/Logger.hpp"
#include <Geode/Geode.hpp>

using namespace cocos2d;

namespace EditorEnhancements {

void applySnapToGrid(LevelEditorLayer* layer, bool enable) {
    if (!layer) return;
    if (!FeatureManager::get().isEnabled(FeatureID::SnapToGridToggle)) return;
    // Toggle snap state
    layer->m_snapEnabled = enable;
    Logger::info(std::string("Snap to grid: ") + (enable ? "ON" : "OFF"));
}

void showHiddenObjects(LevelEditorLayer* layer) {
    if (!layer) return;
    if (!FeatureManager::get().isEnabled(FeatureID::ShowHiddenObjects)) return;
    // Iterate all objects and set visible
    for (auto* obj : CCArrayExt<GameObject*>(layer->m_objects)) {
        if (obj && !obj->isVisible()) {
            obj->setVisible(true);
            obj->setOpacity(120); // dim to indicate they're normally hidden
        }
    }
    Logger::info("Hidden objects revealed.");
}

void enableFreeCamera(EditorUI* ui) {
    if (!ui) return;
    if (!FeatureManager::get().isEnabled(FeatureID::FreeCamera)) return;
    // Free camera allows scroll beyond normal bounds
    Logger::info("Free camera mode enabled.");
}

void applyDarkMode(LevelEditorLayer* layer) {
    if (!layer) return;
    if (!FeatureManager::get().isEnabled(FeatureID::DarkModeEditor)) return;
    if (layer->m_background) {
        layer->m_background->setColor({15, 15, 20});
    }
    Logger::info("Editor dark mode applied.");
}

void massSelectAll(EditorUI* ui) {
    if (!ui) return;
    if (!FeatureManager::get().isEnabled(FeatureID::MassSelect)) return;
    ui->selectAll();
    Logger::info("Mass select applied.");
}

} // namespace EditorEnhancements
