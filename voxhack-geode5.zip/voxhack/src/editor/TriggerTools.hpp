#pragma once
#include <Geode/Geode.hpp>
#include <vector>
namespace TriggerTools {
    void visualizeTriggers(LevelEditorLayer* layer);
    void editTriggerDelay(EffectGameObject* trigger, float delay);
    std::vector<EffectGameObject*> searchTriggersByType(LevelEditorLayer* layer, int typeID);
}
