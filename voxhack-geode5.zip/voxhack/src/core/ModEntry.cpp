#include <Geode/Geode.hpp>
#include "core/ConfigManager.hpp"
#include "core/ThemeManager.hpp"
#include "core/FeatureManager.hpp"
#include "core/SessionManager.hpp"
#include "replay/ReplayManager.hpp"
#include "utils/Logger.hpp"
#include "../include/Globals.hpp"

using namespace geode::prelude;

// Called when the mod is loaded
$on_mod(Loaded) {
    Logger::init();
    Logger::info("=== " GDAC_NAME " v" GDAC_VERSION_STRING " loaded ===");

    // Initialize all core systems in order
    ConfigManager::get();
    Logger::info("ConfigManager initialized.");

    ThemeManager::get();
    Logger::info("ThemeManager initialized.");

    FeatureManager::get();
    Logger::info("FeatureManager initialized.");

    SessionManager::get();
    Logger::info("SessionManager initialized.");

    ReplayManager::get();
    Logger::info("ReplayManager initialized.");

    Logger::info("All systems initialized. GD Advanced Client is ready.");
}
