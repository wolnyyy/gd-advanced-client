#pragma once
#include <string>
#include <vector>
#include <chrono>

class SessionManager {
public:
    static SessionManager& get();

    void reset();
    void onAttemptStart();
    void onDeath(float percent);
    void onLevelComplete();
    void onProgressUpdate(float percent);
    void onJump();
    void onClick();
    void save();

    int   getAttempts()    const { return m_attempts; }
    int   getDeaths()      const { return m_deaths; }
    float getBestPercent() const { return m_bestPercent; }
    int   getJumps()       const { return m_jumps; }
    int   getClicks()      const { return m_clicks; }
    const std::vector<float>& getFailPoints() const { return m_failPoints; }

    std::string getSummary() const;

private:
    SessionManager();

    int   m_attempts   {0};
    int   m_deaths     {0};
    float m_bestPercent{0.f};
    int   m_jumps      {0};
    int   m_clicks     {0};
    std::vector<float> m_failPoints;
    std::string m_savePath;
    std::chrono::steady_clock::time_point m_startTime;
    std::chrono::steady_clock::time_point m_attemptStartTime;
};
