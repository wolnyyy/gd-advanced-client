#pragma once
#include <Geode/Geode.hpp>
#include <string>

namespace PlatformUtils {
    bool isAndroid();
    bool isWindows();
    std::string getSaveDirectory();
    std::string getModDirectory();
    cocos2d::CCSize getScreenSize();
}
