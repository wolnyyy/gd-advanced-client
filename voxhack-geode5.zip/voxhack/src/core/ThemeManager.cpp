#include "ThemeManager.hpp"
#include "ConfigManager.hpp"
#include "../utils/Logger.hpp"

static ThemeManager* s_instance = nullptr;

ThemeManager& ThemeManager::get() {
    if (!s_instance) s_instance = new ThemeManager();
    return *s_instance;
}

ThemeManager::ThemeManager() {
    // Load saved theme
    std::string name = ConfigManager::get().getString("theme", "default");
    applyThemeByName(name);
}

void ThemeManager::applyTheme(ThemeType type) {
    m_current = type;
    switch (type) {
        case ThemeType::Default: m_colors = ThemeColors::makeDefault(); break;
        case ThemeType::Green:   m_colors = ThemeColors::makeGreen();   break;
        case ThemeType::Pink:    m_colors = ThemeColors::makePink();    break;
        case ThemeType::Blue:    m_colors = ThemeColors::makeBlue();    break;
        case ThemeType::Purple:  m_colors = ThemeColors::makePurple();  break;
    }
    ConfigManager::get().set("theme", getCurrentName());
    Logger::info("Theme applied: " + getCurrentName());
}

void ThemeManager::applyThemeByName(const std::string& name) {
    if (name == "green")  applyTheme(ThemeType::Green);
    else if (name == "pink")   applyTheme(ThemeType::Pink);
    else if (name == "blue")   applyTheme(ThemeType::Blue);
    else if (name == "purple") applyTheme(ThemeType::Purple);
    else                       applyTheme(ThemeType::Default);
}

std::string ThemeManager::getCurrentName() const {
    switch (m_current) {
        case ThemeType::Green:  return "green";
        case ThemeType::Pink:   return "pink";
        case ThemeType::Blue:   return "blue";
        case ThemeType::Purple: return "purple";
        default:                return "default";
    }
}

const ThemeColors& ThemeManager::colors() const {
    return m_colors;
}
