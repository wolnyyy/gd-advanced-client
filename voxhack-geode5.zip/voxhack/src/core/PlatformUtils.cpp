#include "PlatformUtils.hpp"
#include "../../include/Platform.hpp"
#include <Geode/Geode.hpp>

namespace PlatformUtils {

bool isAndroid() {
#if GD_PLATFORM_ANDROID
    return true;
#else
    return false;
#endif
}

bool isWindows() {
#if GD_PLATFORM_WINDOWS
    return true;
#else
    return false;
#endif
}

std::string getSaveDirectory() {
    return geode::dirs::getSaveDir().string();
}

std::string getModDirectory() {
    return geode::getMod()->getResourcesDir().string();
}

cocos2d::CCSize getScreenSize() {
    return cocos2d::CCDirector::sharedDirector()->getWinSize();
}

} // namespace PlatformUtils
