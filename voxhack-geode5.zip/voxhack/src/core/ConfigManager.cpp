#include "ConfigManager.hpp"
#include "../utils/Logger.hpp"
#include "../utils/FileUtils.hpp"
#include "../../include/Config.hpp"
#include <Geode/Geode.hpp>
#include <matjson.hpp>
#include <sstream>

static ConfigManager* s_instance = nullptr;

ConfigManager& ConfigManager::get() {
    if (!s_instance) s_instance = new ConfigManager();
    return *s_instance;
}

ConfigManager::ConfigManager() {
    m_configPath = (geode::dirs::getSaveDir() / "gdac_config.json").string();
    loadFromDisk();
}

void ConfigManager::loadFromDisk() {
    if (!FileUtils::exists(m_configPath)) {
        Logger::info("Config not found, creating defaults.");
        setDefaults();
        saveToDisk();
        return;
    }
    std::string raw = FileUtils::readText(m_configPath);
    auto res = matjson::parse(raw);
    if (res.isErr()) {
        Logger::warn("Config parse error, resetting to defaults.");
        setDefaults();
        return;
    }
    m_root = res.unwrap();
    Logger::info("Config loaded from disk.");
}

void ConfigManager::saveToDisk() {
    FileUtils::writeText(m_configPath, m_root.dump());
    Logger::info("Config saved.");
}

void ConfigManager::setDefaults() {
    m_root = matjson::Value::object();
    m_root["theme"] = "default";
    m_root["ui_scale"] = 1.0;
    m_root["compact_mode"] = false;
    m_root["speed_hack_value"] = 1.0;
    m_root["fps_cap"] = 60;
    m_root["keybind_open_panel"] = "Tab";
    m_root["features"] = matjson::Value::object();
    // All features default to false
    for (int i = 1; i < static_cast<int>(FeatureID::COUNT); ++i) {
        m_root["features"][std::to_string(i)] = false;
    }
}

bool ConfigManager::isFeatureEnabled(FeatureID id) const {
    auto key = std::to_string(static_cast<int>(id));
    if (!m_root.contains("features")) return false;
    auto& f = m_root["features"];
    if (!f.contains(key)) return false;
    return f[key].asBool().unwrapOr(false);
}

void ConfigManager::setFeatureEnabled(FeatureID id, bool val) {
    auto key = std::to_string(static_cast<int>(id));
    if (!m_root.contains("features"))
        m_root["features"] = matjson::Value::object();
    m_root["features"][key] = val;
    saveToDisk();
}

std::string ConfigManager::getString(const std::string& key, const std::string& def) const {
    if (!m_root.contains(key)) return def;
    return m_root[key].asString().unwrapOr(def);
}

double ConfigManager::getDouble(const std::string& key, double def) const {
    if (!m_root.contains(key)) return def;
    return m_root[key].asDouble().unwrapOr(def);
}

int ConfigManager::getInt(const std::string& key, int def) const {
    if (!m_root.contains(key)) return def;
    return m_root[key].asInt().unwrapOr(def);
}

bool ConfigManager::getBool(const std::string& key, bool def) const {
    if (!m_root.contains(key)) return def;
    return m_root[key].asBool().unwrapOr(def);
}

void ConfigManager::set(const std::string& key, const std::string& val) {
    m_root[key] = val; saveToDisk();
}
void ConfigManager::set(const std::string& key, double val) {
    m_root[key] = val; saveToDisk();
}
void ConfigManager::set(const std::string& key, int val) {
    m_root[key] = val; saveToDisk();
}
void ConfigManager::set(const std::string& key, bool val) {
    m_root[key] = val; saveToDisk();
}
