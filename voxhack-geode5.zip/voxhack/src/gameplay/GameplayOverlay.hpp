#pragma once
#include <Geode/Geode.hpp>

class GameplayOverlay : public cocos2d::CCNode {
public:
    static GameplayOverlay* create();
    bool init() override;
    void update(float dt) override;
    void setDeaths(int d);

private:
    cocos2d::CCLabelTTF* m_deathLabel {nullptr};
};
