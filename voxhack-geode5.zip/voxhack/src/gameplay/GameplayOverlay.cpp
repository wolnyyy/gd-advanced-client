#include "GameplayOverlay.hpp"
#include "../core/FeatureManager.hpp"
#include "../core/ThemeManager.hpp"
#include "../../include/Config.hpp"

using namespace cocos2d;

GameplayOverlay* GameplayOverlay::create() {
    auto n = new GameplayOverlay();
    if (n && n->init()) { n->autorelease(); return n; }
    CC_SAFE_DELETE(n); return nullptr;
}

bool GameplayOverlay::init() {
    if (!CCNode::init()) return false;

    auto win = CCDirector::sharedDirector()->getWinSize();
    auto& col = ThemeManager::get().colors();

    m_deathLabel = CCLabelTTF::create("Deaths: 0", "Arial", 11.f);
    m_deathLabel->setColor({255,100,100});
    m_deathLabel->setAnchorPoint({0.f, 0.f});
    m_deathLabel->setPosition({5.f, 5.f});
    addChild(m_deathLabel);

    scheduleUpdate();
    return true;
}

void GameplayOverlay::update(float dt) {
    auto& fm = FeatureManager::get();
    if (m_deathLabel)
        m_deathLabel->setVisible(fm.isEnabled(FeatureID::DeathCounter));
}

void GameplayOverlay::setDeaths(int d) {
    if (m_deathLabel) {
        char buf[32];
        snprintf(buf, sizeof(buf), "Deaths: %d", d);
        m_deathLabel->setString(buf);
    }
}
