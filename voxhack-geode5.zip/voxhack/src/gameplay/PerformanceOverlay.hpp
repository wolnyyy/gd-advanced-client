#pragma once
#include <Geode/Geode.hpp>

class PerformanceOverlay : public cocos2d::CCNode {
public:
    static PerformanceOverlay* create();
    bool init() override;
    void update(float dt) override;
private:
    cocos2d::CCLabelTTF* m_label  {nullptr};
    float m_timer  {0.f};
    int   m_frames {0};
};
