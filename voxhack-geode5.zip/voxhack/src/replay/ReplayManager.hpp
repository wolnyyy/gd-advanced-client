#pragma once
#include <string>
#include <vector>

struct ReplayFrame {
    int   frame   {0};
    bool  holding {false};
    float x       {0.f};
    float y       {0.f};
};

class ReplayManager {
public:
    static ReplayManager& get();

    void startRecording();
    void stopRecording();
    void recordFrame(int frame, bool holding, float x, float y);
    bool isRecording() const { return m_recording; }

    void startPlayback();
    void stopPlayback();
    ReplayFrame getNextFrame();
    bool isPlaying() const { return m_playing; }

    bool exportToFile(const std::string& name);
    bool importFromFile(const std::string& path);

    const std::vector<ReplayFrame>& frames() const { return m_frames; }

private:
    ReplayManager();
    std::vector<ReplayFrame> m_frames;
    std::string              m_saveDir;
    bool m_recording {false};
    bool m_playing   {false};
    int  m_playFrame {0};
};
