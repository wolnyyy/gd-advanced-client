#include "ReplayExporter.hpp"
#include "ReplayManager.hpp"
#include "../utils/Logger.hpp"
#include "../utils/FileUtils.hpp"
#include <Geode/Geode.hpp>
#include <sstream>
#include <ctime>

namespace ReplayExporter {

std::string generateFileName() {
    std::time_t t = std::time(nullptr);
    char buf[32];
    std::strftime(buf, sizeof(buf), "replay_%Y%m%d_%H%M%S", std::localtime(&t));
    return std::string(buf);
}

bool exportCurrentReplay() {
    auto name = generateFileName();
    bool ok = ReplayManager::get().exportToFile(name);
    if (ok) Logger::info("Replay exported as: " + name);
    else    Logger::error("Replay export failed.");
    return ok;
}

} // namespace ReplayExporter
