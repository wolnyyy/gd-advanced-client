#include "../../include/Globals.hpp"
#include <Geode/Geode.hpp>
#include <string>
#include <fstream>
#include <chrono>
#include <ctime>
#include <sstream>

namespace Logger {

static std::ofstream s_logFile;
static bool s_initialized = false;

void init() {
    if (s_initialized) return;
    auto path = geode::dirs::getSaveDir() / "gdac_log.txt";
    s_logFile.open(path.string(), std::ios::out | std::ios::trunc);
    s_initialized = true;
    geode::log::info("[GDAC Logger] Initialized. Log: {}", path.string());
}

static std::string timestamp() {
    auto now = std::chrono::system_clock::now();
    std::time_t t = std::chrono::system_clock::to_time_t(now);
    char buf[32];
    std::strftime(buf, sizeof(buf), "%H:%M:%S", std::localtime(&t));
    return std::string(buf);
}

void log(const std::string& level, const std::string& msg) {
    std::string line = "[" + timestamp() + "][" + level + "] " + msg;
    geode::log::info("{}", line);
    if (s_logFile.is_open()) {
        s_logFile << line << "\n";
        s_logFile.flush();
    }
}

void info(const std::string& msg)  { log("INFO",  msg); }
void warn(const std::string& msg)  { log("WARN",  msg); }
void error(const std::string& msg) { log("ERROR", msg); }

} // namespace Logger
