# VoxHack

A professional, modular advanced client for Geometry Dash with 150+ features.

## Requirements

- Geometry Dash 2.206
- Geode v5.0.0-beta.4 or higher

## Installation

1. Download the latest `.geode` file from releases
2. Place it in your Geode mods folder:
   - **Windows**: `%LOCALAPPDATA%/GeometryDash/geode/mods`
   - **macOS**: `~/Library/Application Support/GeometryDash/geode/mods`
   - **Android**: `/data/data/com.robtopx.geometryjumplite/geode/mods`

3. Launch Geometry Dash

## Features

### Practice Mode
- Enhanced checkpoint system
- Training tools
- Practice manager

### Replay System
- Record gameplay
- Playback runs
- Export/import replays

### Editor Tools
- Advanced color tools
- Trigger enhancements
- Editor quality of life improvements

### Gameplay
- FPS counter and unlock
- CPS counter
- Exact percentage display
- Speed hack
- Noclip
- God mode
- Auto jump/restart
- Frame advance

### UI
- Customizable themes (5 included)
- Tab-based interface
- Performance overlay
- Session statistics

### Performance
- FPS unlock (up to 360 FPS)
- Optimized rendering
- Memory management

## Usage

Click the **VOXHACK** button in the main menu to open the control panel.

## Building from Source

### Prerequisites
- CMake 3.21 or higher
- Geode SDK v5.0.0-beta.4
- C++20 compatible compiler

### Build Steps

1. Clone the repository
2. Set the `GEODE_SDK` environment variable to your Geode SDK path
3. Build the project:

```bash
cmake -B build
cmake --build build --config Release
```

4. The compiled `.geode` file will be in `build/` directory

## Configuration

All settings are accessible through the in-game panel. Settings are automatically saved and persist across restarts.

## Support

For issues, feature requests, or questions, please contact the developer team.

## License

All rights reserved.
