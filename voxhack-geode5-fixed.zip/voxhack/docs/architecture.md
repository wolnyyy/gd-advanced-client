# GD Advanced Client – Architecture

## Overview
The mod is organized into 6 primary layers, each with a single responsibility.

### 1. Core System Layer (`src/core/`)
| File | Responsibility |
|------|---------------|
| `ModEntry.cpp` | Geode entry point, initializes all systems |
| `ConfigManager.cpp` | JSON config persistence (matjson) |
| `ThemeManager.cpp` | Dynamic theme switching (5 themes) |
| `FeatureManager.cpp` | Registers and manages all 150 features |
| `SessionManager.cpp` | Local session statistics tracking |
| `PlatformUtils.cpp` | Cross-platform path and screen utilities |

### 2. Feature Modules
| Module | Location |
|--------|----------|
| Gameplay tools | `src/gameplay/` |
| Practice/training | `src/practice/` |
| Level editor | `src/editor/` |
| Replay system | `src/replay/` |

### 3. UI Layer (`src/ui/`)
- `MainPanel` – master panel with 7 tabs
- `TabSystem` – generic tab container
- `ToggleSwitch` – animated on/off toggle
- `SliderControl` – draggable float slider
- `CustomButton` – themed press button
- `SettingsPanel` – speed, FPS, scale settings
- `ThemePanel` – one-click theme switching

### 4. Hook Layer (`src/hooks/`)
Uses Geode's `$modify` macro:
- `MenuLayerHook` – injects GDAC button into main menu
- `PlayLayerHook` – all in-game feature hooks
- `EditorLayerHook` – editor feature hooks

### 5. Utility Layer (`src/utils/`)
- `Logger` – file + Geode log output
- `MathUtils` – lerp, clamp, easing functions
- `FileUtils` – read/write text files

### 6. Config System
- Single JSON file at `[SaveDir]/gdac_config.json`
- Features stored as `{ "features": { "1": false, "2": true, ... } }`
- Hot-reloadable on next panel open

## Data Flow
```
User toggles feature in UI
  → FeatureManager::setEnabled()
    → ConfigManager::setFeatureEnabled()
      → ConfigManager::saveToDisk()
        → gdac_config.json updated

Game hook fires (e.g. PlayLayer::update)
  → FeatureManager::isEnabled(FeatureID::SpeedHack)
    → ConfigManager::isFeatureEnabled()
      → reads cached matjson value
        → returns bool
```

## Adding a New Feature
1. Add enum value to `FeatureID` in `include/Config.hpp`
2. Call `REG(...)` in `FeatureManager::registerAll()`
3. Add hook logic in the appropriate hook file
4. Feature automatically appears in the correct tab's list
