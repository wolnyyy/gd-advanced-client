#pragma once
#include <Geode/Geode.hpp>
#include <vector>
namespace ColorTools {
    cocos2d::ccColor3B generateGradientColor(cocos2d::ccColor3B from, cocos2d::ccColor3B to, float t);
    void applyGradientToObjects(LevelEditorLayer* layer, const std::vector<GameObject*>& objs,
        cocos2d::ccColor3B from, cocos2d::ccColor3B to);
    cocos2d::ccColor3B copyColorFromObject(GameObject* obj);
    cocos2d::ccColor3B hsvToRgb(float h, float s, float v);
}
