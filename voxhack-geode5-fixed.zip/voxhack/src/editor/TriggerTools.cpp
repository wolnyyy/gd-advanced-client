#include "TriggerTools.hpp"
#include "../core/FeatureManager.hpp"
#include "../../include/Config.hpp"
#include "../utils/Logger.hpp"
#include <Geode/Geode.hpp>

using namespace cocos2d;

namespace TriggerTools {

void visualizeTriggers(LevelEditorLayer* layer) {
    if (!layer) return;
    if (!FeatureManager::get().isEnabled(FeatureID::TriggerVisualizer)) return;

    for (auto* obj : CCArrayExt<EffectGameObject*>(layer->m_objects)) {
        if (!obj) continue;
        // Color-code by trigger type
        if (obj->m_objectID == 29) { // Color trigger
            obj->setColor({200, 100, 255});
        } else if (obj->m_objectID == 1049) { // Move trigger
            obj->setColor({100, 200, 255});
        } else if (obj->m_objectID == 30) { // Pulse trigger
            obj->setColor({255, 200, 50});
        }
    }
    Logger::info("Trigger visualization applied.");
}

void editTriggerDelay(EffectGameObject* trigger, float delay) {
    if (!trigger) return;
    if (!FeatureManager::get().isEnabled(FeatureID::TriggerDelayEditor)) return;
    // Modify trigger timing
    trigger->m_duration = delay;
    Logger::info("Trigger delay set to " + std::to_string(delay));
}

std::vector<EffectGameObject*> searchTriggersByType(LevelEditorLayer* layer, int typeID) {
    std::vector<EffectGameObject*> result;
    if (!layer) return result;
    for (auto* obj : CCArrayExt<EffectGameObject*>(layer->m_objects)) {
        if (obj && obj->m_objectID == typeID) result.push_back(obj);
    }
    Logger::info("Found " + std::to_string(result.size()) + " triggers of type " + std::to_string(typeID));
    return result;
}

} // namespace TriggerTools
