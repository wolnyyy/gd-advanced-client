#include "PerformanceOverlay.hpp"
#include "../core/FeatureManager.hpp"
#include "../../include/Config.hpp"

using namespace cocos2d;

PerformanceOverlay* PerformanceOverlay::create() {
    auto n = new PerformanceOverlay();
    if (n && n->init()) { n->autorelease(); return n; }
    CC_SAFE_DELETE(n); return nullptr;
}

bool PerformanceOverlay::init() {
    if (!CCNode::init()) return false;
    auto win = CCDirector::sharedDirector()->getWinSize();

    m_label = CCLabelTTF::create("", "Arial", 10.f);
    m_label->setColor({200,255,200});
    m_label->setAnchorPoint({0.f, 1.f});
    m_label->setPosition({5.f, win.height - 40.f});
    addChild(m_label);

    scheduleUpdate();
    return true;
}

void PerformanceOverlay::update(float dt) {
    if (!FeatureManager::get().isEnabled(FeatureID::ShowFPS)) {
        m_label->setVisible(false);
        return;
    }
    m_label->setVisible(true);
    m_timer += dt;
    ++m_frames;
    if (m_timer >= 1.f) {
        float fps = m_frames / m_timer;
        m_timer  = 0.f;
        m_frames = 0;
        char buf[64];
        snprintf(buf, sizeof(buf), "FPS: %.1f", fps);
        m_label->setString(buf);
    }
}
