#include "VisualToggles.hpp"
#include "../core/FeatureManager.hpp"
#include "../../include/Config.hpp"
#include <Geode/Geode.hpp>

using namespace cocos2d;

namespace VisualToggles {

void applyToPlayLayer(PlayLayer* pl) {
    if (!pl) return;
    auto& fm = FeatureManager::get();

    // No Background
    if (fm.isEnabled(FeatureID::NoBackground) && pl->m_background) {
        pl->m_background->setVisible(false);
    }

    // No Particles
    if (fm.isEnabled(FeatureID::NoParticles)) {
        // Handled via particle system hooks elsewhere
    }

    // No Screen Shake - set shakeStrength to 0
    if (fm.isEnabled(FeatureID::NoScreenShake) && pl->m_gameState.cameraShake) {
        pl->m_gameState.cameraShake = 0.f;
    }

    // Show progress bar numbers
    if (fm.isEnabled(FeatureID::ShowProgressBarNumbers) && pl->m_percentLabel) {
        pl->m_percentLabel->setVisible(true);
    }

    // Minimal HUD
    if (fm.isEnabled(FeatureID::MinimalHUD)) {
        if (pl->m_percentLabel) pl->m_percentLabel->setVisible(false);
        if (pl->m_attemptLabel) pl->m_attemptLabel->setVisible(false);
    }
}

void applyRGBIconsToPlayer(PlayerObject* player, float time) {
    if (!player) return;
    if (!FeatureManager::get().isEnabled(FeatureID::RGBIcons)) return;

    float r = (sinf(time * 2.f) + 1.f) * 0.5f;
    float g = (sinf(time * 2.f + 2.094f) + 1.f) * 0.5f;
    float b = (sinf(time * 2.f + 4.189f) + 1.f) * 0.5f;

    player->setColor({(uint8_t)(r*255), (uint8_t)(g*255), (uint8_t)(b*255)});
}

} // namespace VisualToggles
