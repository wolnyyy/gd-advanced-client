#pragma once
#include <string>

namespace FileUtils {
    bool writeText(const std::string& path, const std::string& content);
    std::string readText(const std::string& path);
    bool exists(const std::string& path);
    bool ensureDir(const std::string& path);
    bool copyFile(const std::string& src, const std::string& dst);
}
