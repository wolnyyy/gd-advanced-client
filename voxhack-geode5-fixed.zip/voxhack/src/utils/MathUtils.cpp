#include "MathUtils.hpp"
#include <cmath>

namespace MathUtils {

float lerp(float a, float b, float t) {
    return a + (b - a) * t;
}

float clamp(float val, float lo, float hi) {
    return val < lo ? lo : (val > hi ? hi : val);
}

float easeOutCubic(float t) {
    float f = 1.f - t;
    return 1.f - f * f * f;
}

float easeInOutQuad(float t) {
    return t < 0.5f ? 2.f * t * t : 1.f - 2.f * (1.f - t) * (1.f - t);
}

cocos2d::CCPoint screenCenter() {
    auto s = cocos2d::CCDirector::sharedDirector()->getWinSize();
    return {s.width * 0.5f, s.height * 0.5f};
}

float uiScale() {
    auto s = cocos2d::CCDirector::sharedDirector()->getWinSize();
    float base = 480.f;
    return clamp(s.height / base, 0.5f, 2.5f);
}

} // namespace MathUtils
