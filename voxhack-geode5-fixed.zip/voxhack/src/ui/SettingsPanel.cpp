#include "SettingsPanel.hpp"
#include "../core/ConfigManager.hpp"
#include "../core/ThemeManager.hpp"
#include "SliderControl.hpp"
#include "ToggleSwitch.hpp"
#include "../../include/Config.hpp"

using namespace cocos2d;

SettingsPanel* SettingsPanel::create(float w, float h) {
    auto n = new SettingsPanel();
    if (n && n->init(w, h)) { n->autorelease(); return n; }
    CC_SAFE_DELETE(n); return nullptr;
}

bool SettingsPanel::init(float w, float h) {
    if (!CCNode::init()) return false;
    setContentSize({w, h});
    auto& col = ThemeManager::get().colors();

    auto title = CCLabelTTF::create("Settings", "Arial", 15.f);
    title->setColor({col.text.r, col.text.g, col.text.b});
    title->setPosition({w * 0.5f, h - 20.f});
    addChild(title);

    float y = h - 55.f;
    float x = 20.f;

    // Speed Hack Slider
    float spd = (float)ConfigManager::get().getDouble(ConfigKeys::SPEED_HACK, 1.0);
    auto speedSlider = SliderControl::create(0.1f, 5.f, spd, "Speed Hack Multiplier",
        [](float v) { ConfigManager::get().set(ConfigKeys::SPEED_HACK, (double)v); });
    speedSlider->setPosition({x, y});
    addChild(speedSlider);
    y -= 45.f;

    // UI Scale Slider
    float scale = (float)ConfigManager::get().getDouble(ConfigKeys::UI_SCALE, 1.0);
    auto scaleSlider = SliderControl::create(0.5f, 2.f, scale, "UI Scale",
        [](float v) { ConfigManager::get().set(ConfigKeys::UI_SCALE, (double)v); });
    scaleSlider->setPosition({x, y});
    addChild(scaleSlider);
    y -= 45.f;

    // FPS cap slider
    float fps = (float)ConfigManager::get().getInt(ConfigKeys::FPS_CAP, 60);
    auto fpsSlider = SliderControl::create(30.f, 360.f, fps, "FPS Cap",
        [](float v) { ConfigManager::get().set(ConfigKeys::FPS_CAP, (int)v); });
    fpsSlider->setPosition({x, y});
    addChild(fpsSlider);
    y -= 45.f;

    // Compact Mode Toggle
    auto cmpLabel = CCLabelTTF::create("Compact Mode", "Arial", 12.f);
    cmpLabel->setColor({col.text.r, col.text.g, col.text.b});
    cmpLabel->setAnchorPoint({0.f, 0.5f});
    cmpLabel->setPosition({x, y});
    addChild(cmpLabel);

    bool cmp = ConfigManager::get().getBool(ConfigKeys::COMPACT_MODE, false);
    auto cmpToggle = ToggleSwitch::create(cmp, [](bool v) {
        ConfigManager::get().set(ConfigKeys::COMPACT_MODE, v);
    });
    cmpToggle->setPosition({w - 70.f, y - 12.f});
    addChild(cmpToggle);

    return true;
}
