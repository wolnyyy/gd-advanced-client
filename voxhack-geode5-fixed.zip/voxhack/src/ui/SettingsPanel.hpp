#pragma once
#include <Geode/Geode.hpp>

class SettingsPanel : public cocos2d::CCNode {
public:
    static SettingsPanel* create(float w, float h);
    bool init(float w, float h);
};
