#include "MainPanel.hpp"
#include "../core/ThemeManager.hpp"
#include "../core/FeatureManager.hpp"
#include "../core/ConfigManager.hpp"
#include "../core/SessionManager.hpp"
#include "ToggleSwitch.hpp"
#include "SettingsPanel.hpp"
#include "ThemePanel.hpp"
#include "../../include/Globals.hpp"
#include "../../include/Config.hpp"
#include "../utils/MathUtils.hpp"

using namespace cocos2d;

MainPanel* MainPanel::s_instance = nullptr;

MainPanel* MainPanel::create() {
    auto n = new MainPanel();
    if (n && n->init()) { n->autorelease(); return n; }
    CC_SAFE_DELETE(n); return nullptr;
}

bool MainPanel::init() {
    if (!CCLayer::init()) return false;
    s_instance = this;

    auto win = CCDirector::sharedDirector()->getWinSize();

    // Dimmed background
    m_dimBg = CCLayerColor::create({0,0,0,150}, win.width, win.height);
    m_dimBg->setPosition({0,0});
    addChild(m_dimBg, 0);

    buildBackground();
    buildTabs();

    setVisible(false);
    setTouchEnabled(true);
    scheduleUpdate();
    return true;
}

void MainPanel::buildBackground() {
    auto win   = CCDirector::sharedDirector()->getWinSize();
    auto& col  = ThemeManager::get().colors();

    float pw = GDACConst::PANEL_WIDTH;
    float ph = GDACConst::PANEL_HEIGHT;
    float px = win.width * 0.5f - pw * 0.5f;
    float py = win.height * 0.5f - ph * 0.5f;

    m_panel = CCNode::create();
    m_panel->setPosition({px, py});
    addChild(m_panel, 1);

    // Panel background
    auto panelBg = CCLayerColor::create(col.panel, pw, ph);
    panelBg->setPosition({0,0});
    m_panel->addChild(panelBg, 0);

    // Border (top line)
    auto border = CCLayerColor::create(col.accent, pw, 2.f);
    border->setPosition({0, ph - 2.f});
    m_panel->addChild(border, 1);

    // Title
    auto title = CCLabelTTF::create(GDAC_NAME " v" GDAC_VERSION_STRING, "Arial", 16.f);
    title->setColor({col.text.r, col.text.g, col.text.b});
    title->setAnchorPoint({0.5f, 0.5f});
    title->setPosition({pw * 0.5f, ph - 16.f});
    m_panel->addChild(title, 2);

    // Session info label
    auto sessInfo = CCLabelTTF::create("", "Arial", 10.f);
    sessInfo->setColor({col.textSecondary.r, col.textSecondary.g, col.textSecondary.b});
    sessInfo->setTag(9999);
    sessInfo->setAnchorPoint({0.f, 0.5f});
    sessInfo->setPosition({5.f, 5.f});
    m_panel->addChild(sessInfo, 2);

    // Close button
    auto closeItem = CCMenuItemLabel::create(
        CCLabelTTF::create("X", "Arial", 14.f),
        [this](CCObject*) { close(); }, nullptr
    );
    auto closeMenu = CCMenu::create(closeItem, nullptr);
    closeMenu->setPosition({pw - 20.f, ph - 16.f});
    m_panel->addChild(closeMenu, 2);
}

CCNode* MainPanel::buildFeatureList(const std::string& category) {
    auto& col = ThemeManager::get().colors();
    float pw = GDACConst::PANEL_WIDTH;
    float ph = GDACConst::PANEL_HEIGHT - 64.f; // below title+tabs

    auto container = CCNode::create();
    container->setContentSize({pw, ph});

    auto features = FeatureManager::get().getByCategory(category);

    // Scrollable list via clip node
    float rowH = 28.f;
    float totalH = features.size() * rowH;
    float startY = totalH > ph ? totalH : ph;

    float y = startY - rowH;
    for (auto fid : features) {
        auto meta = FeatureManager::get().getMeta(fid);
        if (!meta) continue;

        // Row background alternating
        int idx = (int)(y / rowH);
        auto rowBg = CCLayerColor::create({255,255,255, (uint8_t)(idx % 2 == 0 ? 8 : 0)}, pw - 4.f, rowH - 2.f);
        rowBg->setPosition({2.f, y});
        container->addChild(rowBg, 0);

        // Feature name
        auto lbl = CCLabelTTF::create(meta->name.c_str(), "Arial", 11.f);
        lbl->setColor({col.text.r, col.text.g, col.text.b});
        lbl->setAnchorPoint({0.f, 0.5f});
        lbl->setPosition({8.f, y + rowH * 0.5f - 1.f});
        container->addChild(lbl, 1);

        // Toggle switch
        bool enabled = FeatureManager::get().isEnabled(fid);
        auto tog = ToggleSwitch::create(enabled, [fid](bool v) {
            FeatureManager::get().setEnabled(fid, v);
        });
        tog->setPosition({pw - 56.f, y + 2.f});
        container->addChild(tog, 1);

        y -= rowH;
    }

    return container;
}

void MainPanel::buildTabs() {
    auto& col = ThemeManager::get().colors();
    float pw = GDACConst::PANEL_WIDTH;
    float ph = GDACConst::PANEL_HEIGHT;

    // Tab bar at y = ph - 36
    float tabBarY = ph - 36.f;
    float tabH    = 24.f;

    std::vector<std::pair<std::string,std::string>> tabs = {
        {"Gameplay", "Gameplay"},
        {"Practice", "Practice"},
        {"Editor",   "Editor"},
        {"Visual",   "Visual"},
        {"System",   "System"},
        {"Settings", "Settings"},
        {"Theme",    "Theme"}
    };

    float tabW = pw / (float)tabs.size();
    float x = 0.f;

    for (int i = 0; i < (int)tabs.size(); ++i) {
        auto& [id, label] = tabs[i];

        auto tabBg = CCLayerColor::create(col.tabInactive, tabW - 1.f, tabH);
        tabBg->setTag(2000 + i);
        tabBg->setPosition({x, tabBarY});
        m_panel->addChild(tabBg, 1);

        auto tabLbl = CCLabelTTF::create(label.c_str(), "Arial", 9.f);
        tabLbl->setColor({col.text.r, col.text.g, col.text.b});
        tabLbl->setPosition({x + tabW * 0.5f, tabBarY + tabH * 0.5f});
        m_panel->addChild(tabLbl, 2);

        std::string captId = id;
        MainPanel* self = this;

        auto item = CCMenuItemLabel::create(tabLbl, [captId, self, tabs, tabW, tabH, tabBarY, col](CCObject*) {
            // Update tab highlighting
            for (int j = 0; j < (int)tabs.size(); ++j) {
                auto bg = dynamic_cast<CCLayerColor*>(self->m_panel->getChildByTag(2000 + j));
                if (bg) {
                    auto tc = tabs[j].first == captId ? col.tabActive : col.tabInactive;
                    bg->setColor({tc.r, tc.g, tc.b});
                }
            }
            // Show correct content panel
            for (int j = 0; j < (int)tabs.size(); ++j) {
                auto content = self->m_panel->getChildByTag(3000 + j);
                if (content) content->setVisible(tabs[j].first == captId);
            }
        }, nullptr);

        auto menu = CCMenu::create(item, nullptr);
        menu->setPosition({x, tabBarY});
        menu->setContentSize({tabW, tabH});
        m_panel->addChild(menu, 3);

        // Content panels
        CCNode* content = nullptr;
        if (id == "Settings") {
            content = SettingsPanel::create(pw, tabBarY - 4.f);
        } else if (id == "Theme") {
            content = ThemePanel::create(pw, tabBarY - 4.f);
        } else {
            content = buildFeatureList(id);
        }
        content->setPosition({0.f, 0.f});
        content->setVisible(i == 0);
        content->setTag(3000 + i);
        m_panel->addChild(content, 1);

        x += tabW;
    }
}

void MainPanel::open() {
    if (m_open) return;
    m_open = true;
    setVisible(true);

    m_panel->setScale(0.85f);
    m_panel->setOpacity(0);
    m_panel->runAction(CCSpawn::create(
        CCScaleTo::create(GDACConst::ANIM_DURATION, 1.f),
        CCFadeIn::create(GDACConst::ANIM_DURATION),
        nullptr
    ));
    m_dimBg->setOpacity(0);
    m_dimBg->runAction(CCFadeTo::create(GDACConst::ANIM_DURATION, 150));

    // Refresh session summary
    if (auto lbl = dynamic_cast<CCLabelTTF*>(m_panel->getChildByTag(9999))) {
        lbl->setString(SessionManager::get().getSummary().c_str());
    }
}

void MainPanel::close() {
    if (!m_open) return;
    m_open = false;

    m_panel->runAction(CCSequence::create(
        CCSpawn::create(
            CCScaleTo::create(GDACConst::ANIM_DURATION, 0.85f),
            CCFadeOut::create(GDACConst::ANIM_DURATION),
            nullptr
        ),
        CCCallFunc::create([this]() { setVisible(false); }),
        nullptr
    ));
    m_dimBg->runAction(CCFadeTo::create(GDACConst::ANIM_DURATION, 0));
}

bool MainPanel::ccTouchBegan(CCTouch* touch, CCEvent* ev) {
    if (!m_open) return false;
    return true; // Consume all touches when open
}

void MainPanel::ccTouchEnded(CCTouch* touch, CCEvent* ev) {
    if (!m_open) return;
    // Close if clicking outside the panel
    auto pos = m_panel->convertToNodeSpace(touch->getLocation());
    auto size = m_panel->getContentSize();
    if (pos.x < 0 || pos.x > size.width || pos.y < 0 || pos.y > size.height) {
        close();
    }
}
