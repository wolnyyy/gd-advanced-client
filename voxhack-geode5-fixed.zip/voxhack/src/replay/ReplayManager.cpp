#include "ReplayManager.hpp"
#include "../utils/Logger.hpp"
#include "../utils/FileUtils.hpp"
#include <Geode/Geode.hpp>
#include <matjson.hpp>
#include <sstream>

static ReplayManager* s_instance = nullptr;
ReplayManager& ReplayManager::get() {
    if (!s_instance) s_instance = new ReplayManager();
    return *s_instance;
}

ReplayManager::ReplayManager() {
    m_saveDir = (geode::dirs::getSaveDir() / "gdac_replays").string();
    FileUtils::ensureDir(m_saveDir);
}

void ReplayManager::startRecording() {
    m_recording = true;
    m_frames.clear();
    Logger::info("Replay recording started.");
}

void ReplayManager::stopRecording() {
    m_recording = false;
    Logger::info("Replay recording stopped. Frames: " + std::to_string(m_frames.size()));
}

void ReplayManager::recordFrame(int frame, bool holding, float x, float y) {
    if (!m_recording) return;
    m_frames.push_back({frame, holding, x, y});
}

void ReplayManager::startPlayback() {
    m_playing = true;
    m_playFrame = 0;
    Logger::info("Replay playback started.");
}

void ReplayManager::stopPlayback() {
    m_playing = false;
    Logger::info("Replay playback stopped.");
}

ReplayFrame ReplayManager::getNextFrame() {
    if (m_playFrame < (int)m_frames.size()) {
        return m_frames[m_playFrame++];
    }
    m_playing = false;
    return {};
}

bool ReplayManager::exportToFile(const std::string& name) {
    matjson::Value root = matjson::Value::object();
    root["version"] = 1;
    auto arr = matjson::Value::array();
    for (auto& f : m_frames) {
        matjson::Value obj = matjson::Value::object();
        obj["frame"]   = f.frame;
        obj["holding"] = f.holding;
        obj["x"]       = f.x;
        obj["y"]       = f.y;
        arr.push(obj);
    }
    root["frames"] = arr;
    std::string path = m_saveDir + "/" + name + ".json";
    bool ok = FileUtils::writeText(path, root.dump());
    if (ok) Logger::info("Replay exported: " + path);
    return ok;
}

bool ReplayManager::importFromFile(const std::string& path) {
    std::string raw = FileUtils::readText(path);
    if (raw.empty()) { Logger::error("Replay import failed: empty file."); return false; }
    auto res = matjson::parse(raw);
    if (res.isErr()) { Logger::error("Replay import: parse error."); return false; }
    auto root = res.unwrap();
    m_frames.clear();
    for (auto& item : root["frames"].asArray().unwrapOr({})) {
        ReplayFrame f;
        f.frame   = item["frame"].asInt().unwrapOr(0);
        f.holding = item["holding"].asBool().unwrapOr(false);
        f.x       = (float)item["x"].asDouble().unwrapOr(0.0);
        f.y       = (float)item["y"].asDouble().unwrapOr(0.0);
        m_frames.push_back(f);
    }
    Logger::info("Replay imported. Frames: " + std::to_string(m_frames.size()));
    return true;
}
