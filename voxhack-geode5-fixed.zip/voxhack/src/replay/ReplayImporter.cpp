#include "ReplayImporter.hpp"
#include "ReplayManager.hpp"
#include "../utils/Logger.hpp"

namespace ReplayImporter {

bool importReplay(const std::string& filePath) {
    Logger::info("Importing replay from: " + filePath);
    return ReplayManager::get().importFromFile(filePath);
}

} // namespace ReplayImporter
