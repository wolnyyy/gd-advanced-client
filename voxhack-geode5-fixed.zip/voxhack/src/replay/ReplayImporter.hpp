#pragma once
#include <string>
namespace ReplayImporter {
    bool importReplay(const std::string& filePath);
}
