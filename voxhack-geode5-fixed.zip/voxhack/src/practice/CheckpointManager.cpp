#include "CheckpointManager.hpp"
#include "../utils/Logger.hpp"

static CheckpointManager* s_instance = nullptr;
CheckpointManager& CheckpointManager::get() {
    if (!s_instance) s_instance = new CheckpointManager();
    return *s_instance;
}

CheckpointManager::CheckpointManager() {}

void CheckpointManager::addCheckpoint(float percent, float x, float y) {
    m_checkpoints.push_back({percent, x, y});
    Logger::info("Checkpoint added at " + std::to_string(percent) + "%");
}

void CheckpointManager::removeAll() {
    m_checkpoints.clear();
    Logger::info("All checkpoints removed.");
}

CheckpointData* CheckpointManager::getCheckpointAt(float percent) {
    for (auto& cp : m_checkpoints) {
        if (std::abs(cp.percent - percent) < 0.5f) return &cp;
    }
    return nullptr;
}

CheckpointData* CheckpointManager::getNearestBefore(float percent) {
    CheckpointData* best = nullptr;
    for (auto& cp : m_checkpoints) {
        if (cp.percent <= percent) {
            if (!best || cp.percent > best->percent) best = &cp;
        }
    }
    return best;
}
