#include "PracticeManager.hpp"
#include "../core/FeatureManager.hpp"
#include "../core/SessionManager.hpp"
#include "../../include/Config.hpp"
#include "../utils/Logger.hpp"

static PracticeManager* s_instance = nullptr;
PracticeManager& PracticeManager::get() {
    if (!s_instance) s_instance = new PracticeManager();
    return *s_instance;
}

PracticeManager::PracticeManager() {}

void PracticeManager::onPracticeStart() {
    Logger::info("Practice mode started.");
    if (FeatureManager::get().isEnabled(FeatureID::AutoCheckpoints)) {
        m_autoCheckpointTimer = 0.f;
    }
}

void PracticeManager::update(float dt, float percent) {
    auto& fm = FeatureManager::get();

    // Auto checkpoints every 5%
    if (fm.isEnabled(FeatureID::AutoCheckpoints)) {
        m_autoCheckpointTimer += dt;
        if (m_autoCheckpointTimer >= 2.0f) {
            m_autoCheckpointTimer = 0.f;
            m_checkpoints.push_back(percent);
            Logger::info("Auto checkpoint at " + std::to_string(percent) + "%");
        }
    }

    // Section loop
    if (fm.isEnabled(FeatureID::SectionLoop)) {
        if (percent >= m_loopEndPercent && m_loopEndPercent > 0.f) {
            // Signal to restart from loop start
            m_shouldLoop = true;
        }
    }
}

void PracticeManager::setLoopRange(float start, float end) {
    m_loopStartPercent = start;
    m_loopEndPercent   = end;
    Logger::info("Loop range set: " + std::to_string(start) + "% - " + std::to_string(end) + "%");
}

void PracticeManager::addCheckpoint(float percent) {
    m_checkpoints.push_back(percent);
}

void PracticeManager::clearCheckpoints() {
    m_checkpoints.clear();
}

float PracticeManager::getNearestCheckpoint(float currentPercent) const {
    float nearest = 0.f;
    for (float cp : m_checkpoints) {
        if (cp <= currentPercent && cp > nearest) nearest = cp;
    }
    return nearest;
}
