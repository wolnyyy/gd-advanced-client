#pragma once
#include <vector>

class PracticeManager {
public:
    static PracticeManager& get();

    void onPracticeStart();
    void update(float dt, float percent);
    void setLoopRange(float start, float end);
    void addCheckpoint(float percent);
    void clearCheckpoints();
    float getNearestCheckpoint(float currentPercent) const;

    bool shouldLoop() const { return m_shouldLoop; }
    void resetLoop() { m_shouldLoop = false; }
    float getLoopStart() const { return m_loopStartPercent; }

private:
    PracticeManager();
    std::vector<float> m_checkpoints;
    float m_loopStartPercent  {0.f};
    float m_loopEndPercent    {0.f};
    float m_autoCheckpointTimer{0.f};
    bool  m_shouldLoop         {false};
};
