# Changelog

## v1.0.0 - Initial Release

### Added
- Complete advanced client with 150+ features
- Practice mode enhancements
- Replay recording and playback system
- Editor tools and enhancements
- UI customization with themes
- Performance optimizations
- FPS unlock and counter
- Gameplay modifiers (speedhack, noclip, etc.)
- Session tracking and statistics
- VoxHack branding and interface

### Updated
- Compatible with Geode v5.0.0-beta.4
- Updated to work with Geometry Dash 2.206
