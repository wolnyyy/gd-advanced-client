#pragma once
#include <Geode/Geode.hpp>

// ── Platform Detection ────────────────────────────────────────────────────────
#ifdef GEODE_IS_ANDROID
    #define GD_PLATFORM_ANDROID 1
    #define GD_PLATFORM_WINDOWS 0
#else
    #define GD_PLATFORM_ANDROID 0
    #define GD_PLATFORM_WINDOWS 1
#endif

// ── Touch vs Mouse ───────────────────────────────────────────────────────────
#if GD_PLATFORM_ANDROID
    #define GD_HAS_TOUCH 1
    #define GD_HAS_KEYBOARD 0
#else
    #define GD_HAS_TOUCH 0
    #define GD_HAS_KEYBOARD 1
#endif

// ── Path helpers ─────────────────────────────────────────────────────────────
namespace Platform {
    inline std::string getSaveDir() {
        return geode::dirs::getSaveDir().string();
    }
    inline std::string getModResourcesDir() {
        return geode::getMod()->getResourcesDir().string();
    }
    inline float getBaseUIScale() {
#if GD_PLATFORM_ANDROID
        return 1.0f;
#else
        return 1.0f;
#endif
    }
}
