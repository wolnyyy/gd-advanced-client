#pragma once
#include <Geode/Geode.hpp>
#include <string>

struct ThemeColors {
    cocos2d::ccColor4B background;
    cocos2d::ccColor4B panel;
    cocos2d::ccColor4B accent;
    cocos2d::ccColor4B text;
    cocos2d::ccColor4B textSecondary;
    cocos2d::ccColor4B toggleOn;
    cocos2d::ccColor4B toggleOff;
    cocos2d::ccColor4B tabActive;
    cocos2d::ccColor4B tabInactive;
    cocos2d::ccColor4B border;

    static ThemeColors makeDefault() {
        return {
            {10,10,10,230},    // background
            {20,20,20,210},    // panel
            {255,255,255,255}, // accent
            {255,255,255,255}, // text
            {180,180,180,255}, // textSecondary
            {255,255,255,255}, // toggleOn
            {60,60,60,255},    // toggleOff
            {255,255,255,255}, // tabActive
            {40,40,40,255},    // tabInactive
            {80,80,80,255}     // border
        };
    }
    static ThemeColors makeGreen() {
        return {
            {5,15,5,230},
            {10,25,10,210},
            {80,200,80,255},
            {220,255,220,255},
            {150,200,150,255},
            {80,200,80,255},
            {30,60,30,255},
            {80,200,80,255},
            {20,50,20,255},
            {40,100,40,255}
        };
    }
    static ThemeColors makePink() {
        return {
            {20,5,15,230},
            {35,10,25,210},
            {255,105,180,255},
            {255,220,240,255},
            {200,150,175,255},
            {255,105,180,255},
            {80,30,60,255},
            {255,105,180,255},
            {60,15,45,255},
            {180,60,120,255}
        };
    }
    static ThemeColors makeBlue() {
        return {
            {5,10,25,230},
            {10,15,40,210},
            {80,150,255,255},
            {200,220,255,255},
            {130,165,220,255},
            {80,150,255,255},
            {20,40,90,255},
            {80,150,255,255},
            {15,30,70,255},
            {40,80,180,255}
        };
    }
    static ThemeColors makePurple() {
        return {
            {15,5,25,230},
            {25,10,40,210},
            {160,80,255,255},
            {230,200,255,255},
            {170,140,210,255},
            {160,80,255,255},
            {55,20,90,255},
            {160,80,255,255},
            {40,15,70,255},
            {100,40,180,255}
        };
    }
};

enum class ThemeType { Default, Green, Pink, Blue, Purple };
