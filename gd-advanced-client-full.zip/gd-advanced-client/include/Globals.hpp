#pragma once
#include <Geode/Geode.hpp>
#include <string>

// ── Version ───────────────────────────────────────────────────────────────────
#define GDAC_VERSION_MAJOR 1
#define GDAC_VERSION_MINOR 0
#define GDAC_VERSION_PATCH 0
#define GDAC_VERSION_STRING "1.0.0"
#define GDAC_NAME "GD Advanced Client"

// ── Logging macros ────────────────────────────────────────────────────────────
#define GDAC_LOG(msg)   geode::log::info("[GDAC] " msg)
#define GDAC_WARN(msg)  geode::log::warn("[GDAC] " msg)
#define GDAC_ERR(msg)   geode::log::error("[GDAC] " msg)

// ── UI Constants ──────────────────────────────────────────────────────────────
namespace GDACConst {
    constexpr float PANEL_WIDTH       = 420.f;
    constexpr float PANEL_HEIGHT      = 280.f;
    constexpr float CORNER_RADIUS     = 8.f;
    constexpr float ANIM_DURATION     = 0.25f;
    constexpr float TOGGLE_WIDTH      = 44.f;
    constexpr float TOGGLE_HEIGHT     = 24.f;
    constexpr int   Z_ORDER_OVERLAY   = 100;
    constexpr int   Z_ORDER_PANEL     = 200;
}
