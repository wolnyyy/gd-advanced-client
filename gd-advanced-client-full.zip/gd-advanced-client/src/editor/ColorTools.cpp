#include "ColorTools.hpp"
#include "../core/FeatureManager.hpp"
#include "../../include/Config.hpp"
#include "../utils/Logger.hpp"
#include <Geode/Geode.hpp>
#include <cmath>

using namespace cocos2d;

namespace ColorTools {

ccColor3B generateGradientColor(ccColor3B from, ccColor3B to, float t) {
    return {
        (uint8_t)(from.r + (to.r - from.r) * t),
        (uint8_t)(from.g + (to.g - from.g) * t),
        (uint8_t)(from.b + (to.b - from.b) * t)
    };
}

void applyGradientToObjects(
    LevelEditorLayer* layer,
    const std::vector<GameObject*>& objects,
    ccColor3B from, ccColor3B to)
{
    if (!FeatureManager::get().isEnabled(FeatureID::GradientGenerator)) return;
    if (objects.empty()) return;

    for (int i = 0; i < (int)objects.size(); ++i) {
        float t = (float)i / (objects.size() - 1);
        objects[i]->setColor(generateGradientColor(from, to, t));
    }
    Logger::info("Gradient applied to " + std::to_string(objects.size()) + " objects.");
}

ccColor3B copyColorFromObject(GameObject* obj) {
    if (!obj) return {255,255,255};
    return obj->getColor();
}

ccColor3B hsvToRgb(float h, float s, float v) {
    float r=0,g=0,b=0;
    if (s == 0.f) { r=g=b=v; }
    else {
        float i = std::floor(h*6.f);
        float f = h*6.f - i;
        float p = v*(1-s), q=v*(1-s*f), t_=v*(1-s*(1-f));
        switch ((int)i % 6) {
            case 0: r=v;g=t_;b=p; break;
            case 1: r=q;g=v;b=p;  break;
            case 2: r=p;g=v;b=t_; break;
            case 3: r=p;g=q;b=v;  break;
            case 4: r=t_;g=p;b=v; break;
            case 5: r=v;g=p;b=q;  break;
        }
    }
    return {(uint8_t)(r*255),(uint8_t)(g*255),(uint8_t)(b*255)};
}

} // namespace ColorTools
