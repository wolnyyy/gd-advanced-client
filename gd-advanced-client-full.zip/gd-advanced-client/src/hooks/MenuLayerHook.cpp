#include <Geode/Geode.hpp>
#include <Geode/modify/MenuLayer.hpp>
#include "../ui/MainPanel.hpp"
#include "../core/FeatureManager.hpp"
#include "../core/ThemeManager.hpp"
#include "../../include/Globals.hpp"

using namespace geode::prelude;
using namespace cocos2d;

class $modify(GDACMenuLayer, MenuLayer) {
public:
    bool init() {
        if (!MenuLayer::init()) return false;

        auto& col = ThemeManager::get().colors();

        // Inject GD Advanced Client button into main menu
        auto label = CCLabelTTF::create("GDAC", "Arial", 12.f);
        label->setColor({col.accent.r, col.accent.g, col.accent.b});

        auto item = CCMenuItemLabel::create(label, [](CCObject*) {
            // Open main panel
            auto scene = CCDirector::sharedDirector()->getRunningScene();
            if (!scene) return;

            if (!MainPanel::s_instance) {
                auto panel = MainPanel::create();
                scene->addChild(panel, GDACConst::Z_ORDER_PANEL);
            }

            if (MainPanel::s_instance) {
                if (MainPanel::s_instance->isOpen())
                    MainPanel::s_instance->close();
                else
                    MainPanel::s_instance->open();
            }
        }, nullptr);

        auto menu = CCMenu::create(item, nullptr);
        auto win = CCDirector::sharedDirector()->getWinSize();
        menu->setPosition({win.width - 30.f, 20.f});
        addChild(menu, 10);

        return true;
    }
};
