#pragma once
#include <Geode/Geode.hpp>
namespace TrainingTools {
    void drawHitboxTrail(PlayerObject* player, cocos2d::CCNode* layer);
    void renderTimingWindow(cocos2d::CCNode* layer, float percent);
    void renderWaveTrail(PlayerObject* player, cocos2d::CCNode* layer);
}
