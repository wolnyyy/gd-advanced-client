#pragma once
#include <vector>
#include <cmath>

struct CheckpointData {
    float percent {0.f};
    float x       {0.f};
    float y       {0.f};
};

class CheckpointManager {
public:
    static CheckpointManager& get();

    void addCheckpoint(float percent, float x, float y);
    void removeAll();
    CheckpointData* getCheckpointAt(float percent);
    CheckpointData* getNearestBefore(float percent);
    const std::vector<CheckpointData>& all() const { return m_checkpoints; }

private:
    CheckpointManager();
    std::vector<CheckpointData> m_checkpoints;
};
