#include "FileUtils.hpp"
#include "../utils/Logger.hpp"
#include <fstream>
#include <sstream>
#include <filesystem>

namespace fs = std::filesystem;

namespace FileUtils {

bool writeText(const std::string& path, const std::string& content) {
    std::ofstream f(path, std::ios::out | std::ios::trunc);
    if (!f.is_open()) { Logger::error("FileUtils: cannot write " + path); return false; }
    f << content;
    return true;
}

std::string readText(const std::string& path) {
    std::ifstream f(path);
    if (!f.is_open()) { Logger::warn("FileUtils: cannot read " + path); return {}; }
    std::ostringstream ss;
    ss << f.rdbuf();
    return ss.str();
}

bool exists(const std::string& path) {
    return fs::exists(path);
}

bool ensureDir(const std::string& path) {
    std::error_code ec;
    fs::create_directories(path, ec);
    return !ec;
}

bool copyFile(const std::string& src, const std::string& dst) {
    std::error_code ec;
    fs::copy_file(src, dst, fs::copy_options::overwrite_existing, ec);
    return !ec;
}

} // namespace FileUtils
