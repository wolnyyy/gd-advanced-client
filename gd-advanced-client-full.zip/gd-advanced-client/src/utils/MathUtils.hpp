#pragma once
#include <Geode/Geode.hpp>

namespace MathUtils {
    float lerp(float a, float b, float t);
    float clamp(float val, float lo, float hi);
    float easeOutCubic(float t);
    float easeInOutQuad(float t);
    cocos2d::CCPoint screenCenter();
    float uiScale();
}
