#pragma once
#include "../../include/Config.hpp"
#include <matjson.hpp>
#include <string>

class ConfigManager {
public:
    static ConfigManager& get();

    void loadFromDisk();
    void saveToDisk();

    bool   isFeatureEnabled(FeatureID id) const;
    void   setFeatureEnabled(FeatureID id, bool val);

    std::string getString(const std::string& key, const std::string& def = "") const;
    double      getDouble(const std::string& key, double def = 0.0) const;
    int         getInt   (const std::string& key, int def = 0)      const;
    bool        getBool  (const std::string& key, bool def = false)  const;

    void set(const std::string& key, const std::string& val);
    void set(const std::string& key, double val);
    void set(const std::string& key, int val);
    void set(const std::string& key, bool val);

private:
    ConfigManager();
    void setDefaults();

    std::string    m_configPath;
    matjson::Value m_root;
};
