#include "FeatureManager.hpp"
#include "ConfigManager.hpp"
#include "../utils/Logger.hpp"

static FeatureManager* s_instance = nullptr;

FeatureManager& FeatureManager::get() {
    if (!s_instance) { s_instance = new FeatureManager(); }
    return *s_instance;
}

FeatureManager::FeatureManager() {
    registerAll();
    Logger::info("FeatureManager initialized.");
}

void FeatureManager::registerFeature(FeatureID id, const FeatureMeta& meta) {
    m_meta[static_cast<int>(id)] = meta;
}

bool FeatureManager::isEnabled(FeatureID id) const {
    return ConfigManager::get().isFeatureEnabled(id);
}

void FeatureManager::setEnabled(FeatureID id, bool val) {
    ConfigManager::get().setFeatureEnabled(id, val);
}

void FeatureManager::toggle(FeatureID id) {
    setEnabled(id, !isEnabled(id));
}

const FeatureMeta* FeatureManager::getMeta(FeatureID id) const {
    auto it = m_meta.find(static_cast<int>(id));
    return it != m_meta.end() ? &it->second : nullptr;
}

std::vector<FeatureID> FeatureManager::getByCategory(const std::string& cat) const {
    std::vector<FeatureID> out;
    for (auto& [k, v] : m_meta) {
        if (v.category == cat) out.push_back(static_cast<FeatureID>(k));
    }
    return out;
}

void FeatureManager::tick(float dt) {
    for (auto& [id, cb] : m_tickCallbacks) {
        if (ConfigManager::get().isFeatureEnabled(static_cast<FeatureID>(id))) {
            cb();
        }
    }
}

// ─── Register all 150 features ───────────────────────────────────────────────
#define REG(id, name, cat, desc) registerFeature(FeatureID::id, {name, cat, desc})

void FeatureManager::registerAll() {
    // GAMEPLAY
    REG(GodMode,              "God Mode",              "Gameplay", "Prevents the player from dying.");
    REG(AutoComplete,         "Auto Complete",          "Gameplay", "Automatically completes the level.");
    REG(InstantWin,           "Instant Win",            "Gameplay", "Instantly wins the level on start.");
    REG(PracticeMusicSync,    "Practice Music Sync",    "Gameplay", "Keeps music in sync during practice.");
    REG(StartPositionBypass,  "Start Position Bypass",  "Gameplay", "Bypasses start position restrictions.");
    REG(NoClip,               "No Clip",                "Gameplay", "Player passes through obstacles.");
    REG(SafeMode,             "Safe Mode",              "Gameplay", "Disables progress saving.");
    REG(SpeedHack,            "Speed Hack",             "Gameplay", "Adjusts game speed multiplier.");
    REG(SlowMotion,           "Slow Motion",            "Gameplay", "Runs game at reduced speed.");
    REG(FrameAdvance,         "Frame Advance",          "Gameplay", "Advances game one frame at a time.");
    REG(HitboxViewer,         "Hitbox Viewer",          "Gameplay", "Shows all hitboxes.");
    REG(ShowPlayerHitboxOnly, "Show Player Hitbox Only","Gameplay", "Shows only player hitbox.");
    REG(ShowObjectHitboxes,   "Show Object Hitboxes",   "Gameplay", "Shows hitboxes for all objects.");
    REG(DisableSpikes,        "Disable Spikes",         "Gameplay", "Disables spike collision.");
    REG(DisableSawblades,     "Disable Sawblades",      "Gameplay", "Disables sawblade collision.");
    REG(DisableMovingObjects, "Disable Moving Objects", "Gameplay", "Stops all moving objects.");
    REG(NoDeathEffect,        "No Death Effect",        "Gameplay", "Removes the death animation.");
    REG(NoScreenShake,        "No Screen Shake",        "Gameplay", "Disables screen shake effect.");
    REG(NoFlash,              "No Flash",               "Gameplay", "Removes flash effects.");
    REG(NoPulse,              "No Pulse",               "Gameplay", "Removes pulse effects.");
    REG(NoBackground,         "No Background",          "Gameplay", "Hides the level background.");
    REG(NoDecorations,        "No Decorations",         "Gameplay", "Hides decoration objects.");
    REG(NoParticles,          "No Particles",           "Gameplay", "Disables particle effects.");
    REG(NoGlow,               "No Glow",                "Gameplay", "Disables glow effects.");
    REG(NoMirrorPortal,       "No Mirror Portal",       "Gameplay", "Disables mirror portals.");
    REG(NoDualMode,           "No Dual Mode",           "Gameplay", "Disables dual mode.");
    REG(ForceSingleMode,      "Force Single Mode",      "Gameplay", "Forces single player mode.");
    REG(DisableGravityPortals,"Disable Gravity Portals","Gameplay", "Disables gravity portals.");
    REG(JumpHack,             "Jump Hack",              "Gameplay", "Allows jumping anywhere.");
    REG(InfiniteJumps,        "Infinite Jumps",         "Gameplay", "Allows unlimited jumps.");
    REG(AutoJump,             "Auto Jump",              "Gameplay", "Automatically jumps.");
    REG(AutoClick,            "Auto Click",             "Gameplay", "Automatically clicks.");
    REG(ClickBot,             "Click Bot",              "Gameplay", "Plays pre-recorded clicks.");
    REG(BotRecording,         "Bot Recording",          "Gameplay", "Records click inputs.");
    REG(BotPlayback,          "Bot Playback",           "Gameplay", "Plays back recorded inputs.");
    REG(RandomInputBot,       "Random Input Bot",       "Gameplay", "Plays random inputs.");
    REG(ShowCPS,              "Show CPS",               "Gameplay", "Displays clicks per second.");
    REG(AccuracyTracker,      "Accuracy Tracker",       "Gameplay", "Tracks accuracy percentage.");
    REG(DeathCounter,         "Death Counter",          "Gameplay", "Counts deaths.");
    REG(AttemptCounterEditor, "Attempt Counter Editor", "Gameplay", "Edits the attempt counter.");

    // PRACTICE
    REG(AutoCheckpoints,       "Auto Checkpoints",         "Practice", "Places checkpoints automatically.");
    REG(SmartCheckpoints,      "Smart Checkpoints",        "Practice", "Intelligent checkpoint placement.");
    REG(RemoveCheckpoints,     "Remove Checkpoints",       "Practice", "Removes all checkpoints.");
    REG(TeleportToCheckpoint,  "Teleport to Checkpoint",   "Practice", "Instantly teleports to a checkpoint.");
    REG(PracticeBugFix,        "Practice Bug Fix",         "Practice", "Fixes common practice mode bugs.");
    REG(RestartFromPercent,    "Restart From Percent",     "Practice", "Restarts from a specific percent.");
    REG(CustomStartPercent,    "Custom Start Percent",     "Practice", "Sets a custom start percentage.");
    REG(PracticeSpeedControl,  "Practice Speed Control",   "Practice", "Controls speed in practice mode.");
    REG(SectionLoop,           "Section Loop",             "Practice", "Loops a section of the level.");
    REG(SegmentTrainer,        "Segment Trainer",          "Practice", "Trains on specific segments.");
    REG(GhostReplay,           "Ghost Replay",             "Practice", "Shows a ghost of a previous run.");
    REG(CompareRuns,           "Compare Runs",             "Practice", "Compares multiple runs.");
    REG(ShowBestRunOverlay,    "Show Best Run Overlay",    "Practice", "Overlays your best run.");
    REG(ShowFailsLocation,     "Show Fails Location",      "Practice", "Shows where you died most.");
    REG(JumpCounter,           "Jump Counter",             "Practice", "Counts jumps in a run.");
    REG(ClickPatternVisualizer,"Click Pattern Visualizer", "Practice", "Visualizes click patterns.");
    REG(WaveTrailVisualizer,   "Wave Trail Visualizer",    "Practice", "Visualizes wave trail.");
    REG(ShowSafeZones,         "Show Safe Zones",          "Practice", "Highlights safe zones.");
    REG(HitboxTrail,           "Hitbox Trail",             "Practice", "Shows hitbox trail.");
    REG(AttemptHeatmap,        "Attempt Heatmap",          "Practice", "Heatmap of all attempts.");
    REG(MicroStepMode,         "Micro Step Mode",          "Practice", "Steps through physics micro-steps.");
    REG(DelaySimulation,       "Delay Simulation",         "Practice", "Simulates input delay.");
    REG(PhysicsTester,         "Physics Tester",           "Practice", "Tests physics parameters.");
    REG(TimingWindowDisplay,   "Timing Window Display",    "Practice", "Displays timing windows.");
    REG(FrameCounter,          "Frame Counter",            "Practice", "Shows current frame count.");

    // EDITOR
    REG(CopyPasteBetweenLevels,"Copy Paste Between Levels","Editor", "Copies objects between levels.");
    REG(MassSelect,            "Mass Select",              "Editor", "Selects all objects at once.");
    REG(SmartAlign,            "Smart Align",              "Editor", "Aligns objects intelligently.");
    REG(SnapToGridToggle,      "Snap To Grid Toggle",      "Editor", "Toggles grid snapping.");
    REG(FreeMoveObjects,       "Free Move Objects",        "Editor", "Moves objects without grid.");
    REG(RotateAnyObject,       "Rotate Any Object",        "Editor", "Rotates any object freely.");
    REG(ScaleAnyObject,        "Scale Any Object",         "Editor", "Scales any object.");
    REG(CustomObjectSize,      "Custom Object Size",       "Editor", "Sets custom object sizes.");
    REG(UnlockAllObjects,      "Unlock All Objects",       "Editor", "Unlocks all editor objects.");
    REG(UnlockAllColors,       "Unlock All Colors",        "Editor", "Unlocks all color channels.");
    REG(UnlimitedGroups,       "Unlimited Groups",         "Editor", "Removes group limit.");
    REG(UnlimitedColorChannels,"Unlimited Color Channels", "Editor", "Removes color channel limit.");
    REG(ObjectCounterBypass,   "Object Counter Bypass",    "Editor", "Bypasses object count display.");
    REG(RemoveObjectLimit,     "Remove Object Limit",      "Editor", "Removes the object limit.");
    REG(InstantBuildMode,      "Instant Build Mode",       "Editor", "Instant object placement.");
    REG(TemplateSaver,         "Template Saver",           "Editor", "Saves editor templates.");
    REG(MacroBuilder,          "Macro Builder",            "Editor", "Builds editor macros.");
    REG(TriggerVisualizer,     "Trigger Visualizer",       "Editor", "Visualizes all triggers.");
    REG(TriggerSearch,         "Trigger Search",           "Editor", "Searches triggers by type.");
    REG(IDFinder,              "ID Finder",                "Editor", "Finds objects by ID.");
    REG(GroupFinder,           "Group Finder",             "Editor", "Finds objects by group.");
    REG(AdvancedColorPicker,   "Advanced Color Picker",    "Editor", "Enhanced color picker.");
    REG(GradientGenerator,     "Gradient Generator",       "Editor", "Generates color gradients.");
    REG(PulsePreview,          "Pulse Preview",            "Editor", "Previews pulse triggers.");
    REG(CameraZoomEditor,      "Camera Zoom Editor",       "Editor", "Edits camera zoom.");
    REG(FreeCamera,            "Free Camera",              "Editor", "Free-move camera in editor.");
    REG(LayerLock,             "Layer Lock",               "Editor", "Locks editor layers.");
    REG(ShowHiddenObjects,     "Show Hidden Objects",      "Editor", "Shows hidden objects.");
    REG(ObjectInfoPanel,       "Object Info Panel",        "Editor", "Shows object information.");
    REG(BatchEdit,             "Batch Edit",               "Editor", "Edits multiple objects at once.");
    REG(ReplaceObjectTool,     "Replace Object Tool",      "Editor", "Replaces objects of one type.");
    REG(MirrorObjects,         "Mirror Objects",           "Editor", "Mirrors selected objects.");
    REG(RandomizerTool,        "Randomizer Tool",          "Editor", "Randomizes object properties.");
    REG(CopyColorFromObject,   "Copy Color From Object",   "Editor", "Copies color from an object.");
    REG(TriggerDelayEditor,    "Trigger Delay Editor",     "Editor", "Edits trigger delays.");
    REG(HitboxPreviewInEditor, "Hitbox Preview In Editor", "Editor", "Previews hitboxes in editor.");
    REG(CollisionPreview,      "Collision Preview",        "Editor", "Previews collisions.");
    REG(SongWaveformDisplay,   "Song Waveform Display",    "Editor", "Displays song waveform.");
    REG(BPMGridOverlay,        "BPM Grid Overlay",         "Editor", "Overlays BPM grid.");
    REG(AutoSyncToMusic,       "Auto Sync To Music",       "Editor", "Syncs objects to music.");

    // VISUAL/UI
    REG(CustomMenuBackground,  "Custom Menu Background",   "Visual", "Custom main menu background.");
    REG(AnimatedMenu,          "Animated Menu",            "Visual", "Animates the main menu.");
    REG(CustomFonts,           "Custom Fonts",             "Visual", "Uses custom fonts.");
    REG(IconUnlocker,          "Icon Unlocker",            "Visual", "Unlocks all icons locally.");
    REG(RGBIcons,              "RGB Icons",                "Visual", "Makes icons cycle RGB colors.");
    REG(CustomTrails,          "Custom Trails",            "Visual", "Custom player trails.");
    REG(CustomDeathEffect,     "Custom Death Effect",      "Visual", "Custom death explosion.");
    REG(CustomOrbs,            "Custom Orbs",              "Visual", "Custom orb appearance.");
    REG(UIScaling,             "UI Scaling",               "Visual", "Scales the UI.");
    REG(TransparentUI,         "Transparent UI",           "Visual", "Makes UI semi-transparent.");
    REG(CompactMode,           "Compact Mode",             "Visual", "Compact UI layout.");
    REG(ShowFPS,               "Show FPS",                 "Visual", "Displays FPS counter.");
    REG(FPSUnlocker,           "FPS Unlocker",             "Visual", "Unlocks FPS above 60.");
    REG(VSyncToggle,           "VSync Toggle",             "Visual", "Toggles vertical sync.");
    REG(ResolutionUnlock,      "Resolution Unlock",        "Visual", "Allows custom resolutions.");
    REG(BorderlessWindow,      "Borderless Window",        "Visual", "Removes window borders.");
    REG(DarkModeEditor,        "Dark Mode Editor",         "Visual", "Dark theme for the editor.");
    REG(MinimalHUD,            "Minimal HUD",              "Visual", "Minimal in-game HUD.");
    REG(ShowObjectCountInGame, "Show Object Count In Game","Visual", "Shows object count in-game.");
    REG(ShowProgressBarNumbers,"Show Progress Bar Numbers","Visual", "Numbers on progress bar.");

    // SYSTEM
    REG(UnlockAllIcons,          "Unlock All Icons",           "System", "Unlocks all icons locally.");
    REG(UnlockAllColorsGlobal,   "Unlock All Colors Global",   "System", "Unlocks all global colors.");
    REG(UnlockAllAchievements,   "Unlock All Achievements",    "System", "Unlocks all achievements locally.");
    REG(UnlockDemonLevels,       "Unlock Demon Levels",        "System", "Unlocks demon levels locally.");
    REG(UnlockVaults,            "Unlock Vaults",              "System", "Unlocks vaults locally.");
    REG(AutoDailyClaim,          "Auto Daily Claim",           "System", "Auto-claims daily reward.");
    REG(AutoQuestComplete,       "Auto Quest Complete",        "System", "Auto-completes quests.");
    REG(AutoChestOpen,           "Auto Chest Open",            "System", "Auto-opens chests.");
    REG(LevelSkip,               "Level Skip",                 "System", "Skips to next level.");
    REG(ShowExactPercent,        "Show Exact Percent",         "System", "Shows exact progress percent.");
    REG(ExactProgressEditor,     "Exact Progress Editor",      "System", "Edits exact progress locally.");
    REG(BackupSave,              "Backup Save",                "System", "Backs up save file.");
    REG(AutoSave,                "Auto Save",                  "System", "Auto-saves periodically.");
    REG(SaveStateManager,        "Save State Manager",         "System", "Manages local save states.");
    REG(CloudSaveExport,         "Cloud Save Export",          "System", "Exports save to file.");
    REG(ReplayExport,            "Replay Export",              "System", "Exports replay data.");
    REG(ReplayImport,            "Replay Import",              "System", "Imports replay data.");
    REG(AutoRestart,             "Auto Restart",               "System", "Auto-restarts on death.");
    REG(FastRestart,             "Fast Restart",               "System", "Faster restart animation.");
    REG(DisableDeathSound,       "Disable Death Sound",        "System", "Mutes death sound.");
    REG(CustomKeybinds,          "Custom Keybinds",            "System", "Custom keyboard bindings.");
    REG(AdvancedControllerSupport,"Advanced Controller Support","System","Enhanced controller support.");
    REG(MacroSpeedAdjust,        "Macro Speed Adjust",         "System", "Adjusts macro playback speed.");
    REG(SafeRunMode,             "Safe Run Mode",              "System", "Disables online progress.");
    REG(OfflineMode,             "Offline Mode",               "System", "Forces offline mode.");
}
