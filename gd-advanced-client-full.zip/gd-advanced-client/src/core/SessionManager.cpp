#include "SessionManager.hpp"
#include "../utils/Logger.hpp"
#include "../utils/FileUtils.hpp"
#include <Geode/Geode.hpp>
#include <matjson.hpp>
#include <chrono>
#include <sstream>

static SessionManager* s_instance = nullptr;
SessionManager& SessionManager::get() {
    if (!s_instance) s_instance = new SessionManager();
    return *s_instance;
}

SessionManager::SessionManager() {
    m_savePath = (geode::dirs::getSaveDir() / "gdac_session.json").string();
    reset();
}

void SessionManager::reset() {
    m_attempts   = 0;
    m_deaths     = 0;
    m_bestPercent = 0.f;
    m_jumps      = 0;
    m_clicks     = 0;
    m_startTime  = std::chrono::steady_clock::now();
    m_failPoints.clear();
}

void SessionManager::onAttemptStart() {
    ++m_attempts;
    m_attemptStartTime = std::chrono::steady_clock::now();
}

void SessionManager::onDeath(float percent) {
    ++m_deaths;
    m_failPoints.push_back(percent);
}

void SessionManager::onLevelComplete() {
    m_bestPercent = 100.f;
}

void SessionManager::onProgressUpdate(float percent) {
    if (percent > m_bestPercent) m_bestPercent = percent;
}

void SessionManager::onJump()  { ++m_jumps; }
void SessionManager::onClick() { ++m_clicks; }

void SessionManager::save() {
    matjson::Value root = matjson::Value::object();
    root["attempts"]    = m_attempts;
    root["deaths"]      = m_deaths;
    root["best_pct"]    = m_bestPercent;
    root["jumps"]       = m_jumps;
    root["clicks"]      = m_clicks;

    auto arr = matjson::Value::array();
    for (float f : m_failPoints) arr.push(f);
    root["fail_points"] = arr;

    FileUtils::writeText(m_savePath, root.dump());
    Logger::info("Session saved.");
}

std::string SessionManager::getSummary() const {
    std::ostringstream ss;
    ss << "Attempts: "   << m_attempts
       << "  Deaths: "   << m_deaths
       << "  Best: "     << m_bestPercent << "%"
       << "  Jumps: "    << m_jumps
       << "  Clicks: "   << m_clicks;
    return ss.str();
}
