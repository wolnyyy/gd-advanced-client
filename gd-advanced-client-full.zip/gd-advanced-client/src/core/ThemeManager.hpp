#pragma once
#include "../../include/Theme.hpp"
#include <string>

class ThemeManager {
public:
    static ThemeManager& get();

    void applyTheme(ThemeType type);
    void applyThemeByName(const std::string& name);
    std::string getCurrentName() const;
    const ThemeColors& colors() const;
    ThemeType currentType() const { return m_current; }

private:
    ThemeManager();
    ThemeType   m_current { ThemeType::Default };
    ThemeColors m_colors;
};
