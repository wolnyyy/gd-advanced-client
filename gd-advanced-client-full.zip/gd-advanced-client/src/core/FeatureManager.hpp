#pragma once
#include "../../include/Config.hpp"
#include <functional>
#include <unordered_map>
#include <string>

struct FeatureMeta {
    std::string name;
    std::string category;
    std::string description;
};

class FeatureManager {
public:
    static FeatureManager& get();

    void registerFeature(FeatureID id, const FeatureMeta& meta);
    bool isEnabled(FeatureID id) const;
    void setEnabled(FeatureID id, bool val);
    void toggle(FeatureID id);

    const FeatureMeta* getMeta(FeatureID id) const;
    std::vector<FeatureID> getByCategory(const std::string& cat) const;

    // Called each frame for active features
    void tick(float dt);

private:
    FeatureManager();
    void registerAll();

    std::unordered_map<int, FeatureMeta>           m_meta;
    std::unordered_map<int, std::function<void()>> m_tickCallbacks;
};
