#pragma once
#include <Geode/Geode.hpp>
namespace VisualToggles {
    void applyToPlayLayer(PlayLayer* pl);
    void applyRGBIconsToPlayer(PlayerObject* player, float time);
}
