#pragma once
#include <Geode/Geode.hpp>
#include <functional>
#include <vector>
#include <string>

struct Tab {
    std::string id;
    std::string label;
    cocos2d::CCNode* content {nullptr};
};

class TabSystem : public cocos2d::CCNode {
public:
    static TabSystem* create(float width, float height);
    bool init(float width, float height);

    void addTab(const std::string& id, const std::string& label, cocos2d::CCNode* content);
    void switchTab(const std::string& id);
    std::string currentTab() const { return m_currentTab; }

    void setOnTabChange(std::function<void(const std::string&)> cb) { m_onTabChange = cb; }

private:
    void rebuildTabBar();

    std::vector<Tab>        m_tabs;
    std::string             m_currentTab;
    cocos2d::CCNode*        m_tabBar    {nullptr};
    cocos2d::CCNode*        m_content   {nullptr};
    std::function<void(const std::string&)> m_onTabChange;
    float m_width{0.f}, m_height{0.f};
    static constexpr float TAB_H = 32.f;
};
