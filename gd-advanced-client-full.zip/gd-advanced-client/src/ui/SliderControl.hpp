#pragma once
#include <Geode/Geode.hpp>
#include <functional>

class SliderControl : public cocos2d::CCNode {
public:
    static SliderControl* create(float min, float max, float value,
        const std::string& label, std::function<void(float)> onChange);
    bool init(float min, float max, float value,
        const std::string& label, std::function<void(float)> onChange);

    void setValue(float v);
    float getValue() const { return m_value; }

    bool onTouchBegan(cocos2d::CCTouch*, cocos2d::CCEvent*);
    void onTouchMoved(cocos2d::CCTouch*, cocos2d::CCEvent*);
    void onTouchEnded(cocos2d::CCTouch*, cocos2d::CCEvent*);

private:
    void updateThumb();
    float posToValue(float x);

    cocos2d::CCLayerColor* m_track  {nullptr};
    cocos2d::CCLayerColor* m_fill   {nullptr};
    cocos2d::CCLayerColor* m_thumb  {nullptr};
    cocos2d::CCLabelTTF*   m_label  {nullptr};
    cocos2d::CCLabelTTF*   m_valLabel{nullptr};
    std::function<void(float)> m_onChange;
    float m_min{0.f}, m_max{1.f}, m_value{0.5f};
    bool  m_dragging{false};

    static constexpr float TRACK_W = 200.f;
    static constexpr float TRACK_H = 6.f;
    static constexpr float THUMB_R = 10.f;
    static constexpr float TOTAL_H = 36.f;
};
