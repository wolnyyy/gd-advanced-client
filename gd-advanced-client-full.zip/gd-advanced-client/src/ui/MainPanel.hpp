#pragma once
#include <Geode/Geode.hpp>

class MainPanel : public cocos2d::CCLayer {
public:
    static MainPanel* create();
    bool init() override;

    void open();
    void close();
    bool isOpen() const { return m_open; }

    // Touch dispatch
    bool ccTouchBegan(cocos2d::CCTouch*, cocos2d::CCEvent*) override;
    void ccTouchEnded(cocos2d::CCTouch*, cocos2d::CCEvent*) override;

    static MainPanel* s_instance;

private:
    void buildBackground();
    void buildTabs();
    cocos2d::CCNode* buildFeatureList(const std::string& category);
    void onKeyPressed(cocos2d::enumKeyCodes key, bool down);

    cocos2d::CCLayerColor* m_bg      {nullptr};
    cocos2d::CCLayerColor* m_dimBg   {nullptr};
    cocos2d::CCNode*       m_panel   {nullptr};
    bool                   m_open    {false};
};
