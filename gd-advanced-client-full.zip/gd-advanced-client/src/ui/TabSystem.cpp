#include "TabSystem.hpp"
#include "../core/ThemeManager.hpp"

using namespace cocos2d;

TabSystem* TabSystem::create(float w, float h) {
    auto n = new TabSystem();
    if (n && n->init(w, h)) { n->autorelease(); return n; }
    CC_SAFE_DELETE(n); return nullptr;
}

bool TabSystem::init(float w, float h) {
    if (!CCNode::init()) return false;
    m_width = w; m_height = h;
    setContentSize({w, h});

    m_tabBar = CCNode::create();
    m_tabBar->setPosition({0.f, h - TAB_H});
    addChild(m_tabBar, 1);

    m_content = CCNode::create();
    m_content->setPosition({0.f, 0.f});
    addChild(m_content, 0);

    return true;
}

void TabSystem::addTab(const std::string& id, const std::string& label, CCNode* content) {
    m_tabs.push_back({id, label, content});
    content->setVisible(false);
    m_content->addChild(content);

    if (m_currentTab.empty()) {
        m_currentTab = id;
        content->setVisible(true);
    }
    rebuildTabBar();
}

void TabSystem::switchTab(const std::string& id) {
    if (m_currentTab == id) return;
    for (auto& t : m_tabs) {
        if (t.content) t.content->setVisible(t.id == id);
    }
    m_currentTab = id;
    rebuildTabBar();
    if (m_onTabChange) m_onTabChange(id);
}

void TabSystem::rebuildTabBar() {
    m_tabBar->removeAllChildren();
    auto& col = ThemeManager::get().colors();

    float tabW = m_tabs.empty() ? m_width : m_width / (float)m_tabs.size();
    float x = 0.f;

    for (auto& t : m_tabs) {
        bool active = (t.id == m_currentTab);
        auto bg = CCLayerColor::create(active ? col.tabActive : col.tabInactive, tabW - 2.f, TAB_H);
        bg->setPosition({x + 1.f, 0.f});
        m_tabBar->addChild(bg);

        auto lbl = CCLabelTTF::create(t.label.c_str(), "Arial", 12.f);
        lbl->setColor({col.text.r, col.text.g, col.text.b});
        lbl->setPosition({x + tabW * 0.5f, TAB_H * 0.5f});
        m_tabBar->addChild(lbl);

        // Touch handling via CCMenu
        auto item = CCMenuItemLabel::create(lbl, nullptr, nullptr);
        // We use CCMenu for simple clicking
        std::string capturedId = t.id;
        auto menu = CCMenu::create();
        menu->setPosition({x, 0.f});
        auto btn = CCMenuItemColor::create(active ? col.tabActive : col.tabInactive, tabW-2.f, TAB_H);
        // For simplicity we store callback in lambda via scheduleOnce trick
        // Using direct touch-based approach on the tab bar instead
        m_tabBar->addChild(menu);

        x += tabW;
    }
}
