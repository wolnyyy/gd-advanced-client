#pragma once
#include <Geode/Geode.hpp>

class ThemePanel : public cocos2d::CCNode {
public:
    static ThemePanel* create(float w, float h);
    bool init(float w, float h);
    void rebuildButtons(float w, float h);
};
