#include "ToggleSwitch.hpp"
#include "../core/ThemeManager.hpp"

using namespace cocos2d;

ToggleSwitch* ToggleSwitch::create(bool init_, std::function<void(bool)> onChange) {
    auto node = new ToggleSwitch();
    if (node && node->init(init_, onChange)) { node->autorelease(); return node; }
    CC_SAFE_DELETE(node); return nullptr;
}

bool ToggleSwitch::init(bool initState, std::function<void(bool)> onChange) {
    if (!CCNode::init()) return false;
    m_onChange = onChange;
    m_state    = initState;
    setContentSize({W, H});

    auto& col = ThemeManager::get().colors();

    m_track = CCLayerColor::create(col.toggleOff, W, H);
    m_track->setPosition({0,0});
    addChild(m_track);

    m_thumb = CCLayerColor::create({255,255,255,255}, THUMB_R*2, THUMB_R*2);
    addChild(m_thumb);

    updateVisuals(false);
    setTouchEnabled(true);
    return true;
}

void ToggleSwitch::setState(bool state, bool animate) {
    m_state = state;
    updateVisuals(animate);
}

void ToggleSwitch::updateVisuals(bool animate) {
    auto& col = ThemeManager::get().colors();
    float targetX = m_state ? (W - THUMB_R*2 - 2.f) : 2.f;
    float targetY = (H - THUMB_R*2) * 0.5f;

    auto trackCol = m_state ? col.toggleOn : col.toggleOff;
    m_track->setColor({trackCol.r, trackCol.g, trackCol.b});

    if (animate) {
        m_thumb->runAction(CCMoveTo::create(0.15f, {targetX, targetY}));
    } else {
        m_thumb->setPosition({targetX, targetY});
    }
}

bool ToggleSwitch::onTouchBegan(CCTouch* touch, CCEvent*) {
    auto pos  = convertToNodeSpace(touch->getLocation());
    auto size = getContentSize();
    return (pos.x >= 0 && pos.x <= size.width && pos.y >= 0 && pos.y <= size.height);
}

void ToggleSwitch::onTouchEnded(CCTouch* touch, CCEvent*) {
    auto pos  = convertToNodeSpace(touch->getLocation());
    auto size = getContentSize();
    if (pos.x >= 0 && pos.x <= size.width && pos.y >= 0 && pos.y <= size.height) {
        m_state = !m_state;
        updateVisuals(true);
        if (m_onChange) m_onChange(m_state);
    }
}
