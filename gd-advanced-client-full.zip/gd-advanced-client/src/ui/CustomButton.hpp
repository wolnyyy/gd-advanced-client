#pragma once
#include <Geode/Geode.hpp>
#include <functional>

class CustomButton : public cocos2d::CCNode {
public:
    static CustomButton* create(
        const std::string& label,
        const cocos2d::ccColor4B& bgColor,
        const cocos2d::ccColor4B& textColor,
        const cocos2d::CCSize& size,
        std::function<void()> callback
    );

    bool init(
        const std::string& label,
        const cocos2d::ccColor4B& bgColor,
        const cocos2d::ccColor4B& textColor,
        const cocos2d::CCSize& size,
        std::function<void()> callback
    );

    void setLabel(const std::string& label);
    void setEnabled(bool enabled);

    bool onTouchBegan(cocos2d::CCTouch* touch, cocos2d::CCEvent* event);
    void onTouchEnded(cocos2d::CCTouch* touch, cocos2d::CCEvent* event);

private:
    cocos2d::CCLayerColor*    m_bg      {nullptr};
    cocos2d::CCLabelTTF*      m_label   {nullptr};
    std::function<void()>     m_callback;
    cocos2d::ccColor4B        m_bgColor;
    bool                      m_enabled {true};
    bool                      m_pressed {false};
};
