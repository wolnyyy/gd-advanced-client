#include "SliderControl.hpp"
#include "../core/ThemeManager.hpp"
#include <sstream>
#include <iomanip>

using namespace cocos2d;

SliderControl* SliderControl::create(float min, float max, float value,
    const std::string& label, std::function<void(float)> onChange)
{
    auto n = new SliderControl();
    if (n && n->init(min, max, value, label, onChange)) { n->autorelease(); return n; }
    CC_SAFE_DELETE(n); return nullptr;
}

bool SliderControl::init(float min, float max, float value,
    const std::string& label, std::function<void(float)> onChange)
{
    if (!CCNode::init()) return false;
    m_min = min; m_max = max; m_value = value; m_onChange = onChange;

    auto& col = ThemeManager::get().colors();
    setContentSize({TRACK_W + 20.f, TOTAL_H});

    float cy = TOTAL_H * 0.5f;

    m_track = CCLayerColor::create(col.border, TRACK_W, TRACK_H);
    m_track->setPosition({10.f, cy - TRACK_H * 0.5f});
    addChild(m_track, 0);

    m_fill = CCLayerColor::create(col.accent, 1.f, TRACK_H);
    m_fill->setPosition({10.f, cy - TRACK_H * 0.5f});
    addChild(m_fill, 1);

    m_thumb = CCLayerColor::create({255,255,255,255}, THUMB_R*2, THUMB_R*2);
    addChild(m_thumb, 2);

    m_label = CCLabelTTF::create(label.c_str(), "Arial", 11.f);
    m_label->setColor({col.textSecondary.r, col.textSecondary.g, col.textSecondary.b});
    m_label->setAnchorPoint({0.f, 0.5f});
    m_label->setPosition({10.f, TOTAL_H - 8.f});
    addChild(m_label, 3);

    m_valLabel = CCLabelTTF::create("", "Arial", 11.f);
    m_valLabel->setColor({col.text.r, col.text.g, col.text.b});
    m_valLabel->setAnchorPoint({1.f, 0.5f});
    m_valLabel->setPosition({TRACK_W + 10.f, TOTAL_H - 8.f});
    addChild(m_valLabel, 3);

    updateThumb();
    setTouchEnabled(true);
    return true;
}

void SliderControl::setValue(float v) {
    m_value = v < m_min ? m_min : (v > m_max ? m_max : v);
    updateThumb();
}

void SliderControl::updateThumb() {
    float t = (m_max > m_min) ? (m_value - m_min) / (m_max - m_min) : 0.f;
    float x = 10.f + t * TRACK_W;
    float cy = TOTAL_H * 0.5f;
    m_thumb->setPosition({x - THUMB_R, cy - THUMB_R});
    m_fill->setScaleX(t * TRACK_W > 1.f ? t * TRACK_W : 1.f);

    std::ostringstream ss;
    ss << std::fixed << std::setprecision(2) << m_value;
    m_valLabel->setString(ss.str().c_str());
}

float SliderControl::posToValue(float x) {
    float t = (x - 10.f) / TRACK_W;
    t = t < 0.f ? 0.f : (t > 1.f ? 1.f : t);
    return m_min + t * (m_max - m_min);
}

bool SliderControl::onTouchBegan(CCTouch* touch, CCEvent*) {
    auto p = convertToNodeSpace(touch->getLocation());
    float cy = TOTAL_H * 0.5f;
    if (p.x >= 10.f && p.x <= TRACK_W+10.f && p.y >= cy - 14.f && p.y <= cy + 14.f) {
        m_dragging = true;
        m_value = posToValue(p.x);
        updateThumb();
        if (m_onChange) m_onChange(m_value);
        return true;
    }
    return false;
}

void SliderControl::onTouchMoved(CCTouch* touch, CCEvent*) {
    if (!m_dragging) return;
    auto p = convertToNodeSpace(touch->getLocation());
    m_value = posToValue(p.x);
    updateThumb();
    if (m_onChange) m_onChange(m_value);
}

void SliderControl::onTouchEnded(CCTouch*, CCEvent*) {
    m_dragging = false;
}
