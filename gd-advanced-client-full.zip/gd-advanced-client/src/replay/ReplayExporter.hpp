#pragma once
#include <string>
namespace ReplayExporter {
    std::string generateFileName();
    bool exportCurrentReplay();
}
